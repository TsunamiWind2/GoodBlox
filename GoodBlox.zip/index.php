<?php
require 'goodblox/core/config.php';
$GLOBALS['site'] = new site();
print($GLOBALS['site']->getDependencies(1, "GoodBlox: We're Good", "GoodBlox is a 2007 revival aiming to replicate ROBLOX as it was in 2007!", $GLOBALS['baseURL'].'resources/images/logo.png'));
print($GLOBALS['site']->getHeader(true)); //true - show nav, false - dont show nav
//some cool login
$err = '';  
if(isset($_POST['lb'])) {
    //login post
    $un = trim($_POST['un']);
    $pw = $_POST['pw'];
    $stmt = $pdo->prepare("SELECT * FROM users WHERE username = :un LIMIT 1");
    $stmt->execute(['un' => $un]);
    $usr = $stmt->fetch(PDO::FETCH_ASSOC);
    if($usr && password_verify($pw, $usr['password'])) {
        //uid, token, ip, country = null, user_agent, valid = 1
        $token = bin2hex(random_bytes(32));
        $userip = hash('sha256', $_SERVER['REMOTE_ADDR']);
        $GLOBALS['authentication']->createSESSION(intval($usr['id']), $token, $userip, $_SERVER['HTTP_USER_AGENT']);
        //success
        header("Location: /");
        die();
    } else {
        //real goodblox error
        $err = "Incorrect username or password. Please try again.";
    }
}
?>
<div id="Body">
    <div id="SplashContainer">
      <div id="SignInPane">

                            <div id="LoginViewContainer">
          
          <div id="LoginView">
                          <h5>Member Login</h5>

            <?php if(!$GLOBALS['user']->isLoggedIn()) { ?><div class="AspNet-Login">
              <form class="AspNet-Login" method="post">
                 <?php if(isset($err)) { ?><div style="color:red;"><?php echo $err; ?></div><?php } ?>
                                  <div class="AspNet-Login-UserPanel">
                  <label class="Label">Character Name</label>
                  <input name="un" tabindex="1" class="Text" style="background-image: url(&quot;data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAASCAYAAABSO15qAAAAAXNSR0IArs4c6QAAAPhJREFUOBHlU70KgzAQPlMhEvoQTg6OPoOjT+JWOnRqkUKHgqWP4OQbOPokTk6OTkVULNSLVc62oJmbIdzd95NcuGjX2/3YVI/Ts+t0WLE2ut5xsQ0O+90F6UxFjAI8qNcEGONia08e6MNONYwCS7EQAizLmtGUDEzTBNd1fxsYhjEBnHPQNG3KKTYV34F8ec/zwHEciOMYyrIE3/ehKAqIoggo9inGXKmFXwbyBkmSQJqmUNe15IRhCG3byphitm1/eUzDM4qR0TTNjEixGdAnSi3keS5vSk2UDKqqgizLqB4YzvassiKhGtZ/jDMtLOnHz7TE+yf8BaDZXA509yeBAAAAAElFTkSuQmCC&quot;); background-repeat: no-repeat; background-attachment: scroll; background-size: 16px 18px; background-position: 98% 50%; cursor: auto;" autocomplete="off" type="text">
                </div>
                <div class="AspNet-Login-PasswordPanel">
                  <label class="Label">Password</label>
                  <input name="pw" tabindex="2" class="Text" style="background-image: url(&quot;data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAASCAYAAABSO15qAAAAAXNSR0IArs4c6QAAAPhJREFUOBHlU70KgzAQPlMhEvoQTg6OPoOjT+JWOnRqkUKHgqWP4OQbOPokTk6OTkVULNSLVc62oJmbIdzd95NcuGjX2/3YVI/Ts+t0WLE2ut5xsQ0O+90F6UxFjAI8qNcEGONia08e6MNONYwCS7EQAizLmtGUDEzTBNd1fxsYhjEBnHPQNG3KKTYV34F8ec/zwHEciOMYyrIE3/ehKAqIoggo9inGXKmFXwbyBkmSQJqmUNe15IRhCG3byphitm1/eUzDM4qR0TTNjEixGdAnSi3keS5vSk2UDKqqgizLqB4YzvassiKhGtZ/jDMtLOnHz7TE+yf8BaDZXA509yeBAAAAAElFTkSuQmCC&quot;); background-repeat: no-repeat; background-attachment: scroll; background-size: 16px 18px; background-position: 98% 50%; cursor: auto;" autocomplete="off" type="password">
                </div>
                <div class="AspNet-Login-SubmitPanel">
                  <button type="submit" name="lb" tabindex="4" class="Button">Login</button>
                </div>
                <div class="AspNet-Login-PasswordRecoveryPanel">
                  <a tabindex="5" href="#">Forgot your password?</a>
                </div>
              </form>

                          </div><?php } else { ?>
            <div id="AlreadySignedIn">
          <a id="ctl00_cphRoblox_rbxLoginView_lvLoginView_rbxContentImage" title="<?php echo $GLOBALS['site']->cleanOutput($GLOBALS['self']->username); ?>" href="/my/home" style="display:inline-block;height:200px;width:150px;cursor:pointer;"><img src="/goodblox/images/render/avatar/<?php echo intval($GLOBALS['self']->id); ?>.png" onerror="this.onerror=null; this.src='<?php echo $GLOBALS['baseURL']; ?>/goodblox/images/render/avatar/default.png';" width="150px" border="0" id="img" alt="<?php echo $GLOBALS['site']->cleanOutput($GLOBALS['self']->username); ?>"></a>
        </div>
            <?php } ?>
                        </div>
        </div>
            
        <div id="ctl00_cphRoblox_pFigure">

          <div id="Figure">
            <a id="ctl00_cphRoblox_ImageFigure" disabled="disabled" title="Figure" onclick="return false" style="display:inline-block;">
              <img src="resources/speech.png" id="img" alt="A message" border="0" style="position:absolute;margin-left:-50px;margin-top:-85px;">
              <img src="resources/figure.png" id="img" alt="Figure" border="0" style="margin-left: 80px;position:absolute;">
            </a>
          </div>

        </div>

      </div>
      <div id="GobloxAtAGlance">
        <h2>GoodBlox</h2>
        <h3>GoodBlox is Good!</h3>
        <ul id="ThingsToDo">
          <li id="Point1">
            <h3>Experience nostalgia</h3>
            <div>Create buildings, vehicles, scenery, and traps with thousands of virtual bricks in 2007!</div>
          </li>
          <li id="Point2">
            <h3>Meet new friends online</h3>
            <div>Visit a range of servers, chat in 3D, and build together.</div>
          </li>
          <li id="Point3">
            <h3>Battle in the Brick Arenas</h3>
            <div>Play with the slingshot, rocket, or other brick battle tools.  Be careful not to get "bloxxed".</div>
          </li>
        </ul>
        <div id="Showcase">
                    <iframe width="400" height="326" src="https://www.youtube.com/embed/oDVAjvNeGA8?si=05os-M3QCanpPxFt" frameborder="0" data-ruffle-polyfilled=""></iframe>
          </div>
        <div id="Install">
          <div id="DownloadAndPlay">
            <a id="ctl00_cphRoblox_hlDownloadAndPlay" href="">
              <img src="resources/DownloadAndPlay.png" alt="FREE - Download and Play!" border="0">
            </a>
          </div>
        </div>
      </div>
      <div id="UserPlacesPane">
        <div id="UserPlaces_Content">
          <table id="ctl00_cphRoblox_DataListCoolPlace" width="100%" cellspacing="0" border="0">
            <tbody>
              <tr>
                <td class="UserPlace">
                  <a id="ctl00_cphRoblox_DataListCoolPlace_ctl00_rbxContentImage" title="Our Discord Server" href="https://discord.gg/zuqXUHr" style="display:inline-block;cursor:pointer;margin-top:-10px;"><img src="resources/discord.png" id="img" alt="Our Discord Server" border="0" width="85" height="85"></a>
                </td>
                <td class="UserPlace">
                  <a id="ctl00_cphRoblox_DataListCoolPlace_ctl01_rbxContentImage" title="Our YouToob Channel" href="https://youtube.com/user/goodblox" style="display:inline-block;cursor:pointer;"><img src="resources/youtube.png" id="img" alt="Our YouToob Channel" border="0"></a>
                </td>
                <td class="UserPlace">
                  <a id="ctl00_cphRoblox_DataListCoolPlace_ctl02_rbxContentImage" title="Our Twitter Page" href="https://twitter.com/goodbIox" style="display:inline-block;cursor:pointer;margin-left:30px;"><img src="resources/Twitter1.png" id="img" alt="Our Twitter Page" border="0" height="50" width="50"></a>
                </td>
                <td class="UserPlace">
                  <a id="ctl00_cphRoblox_DataListCoolPlace_ctl03_rbxContentImage" title="E-mail us!" href="mailto:info@goodblox.com" style="display:inline-block;cursor:pointer;"><img src="resources/mail.png" id="img" alt="E-mail us!" width="80" height="80" border="0"></a>
                </td>
                <td class="UserPlace">
                  <a id="ctl00_cphRoblox_DataListCoolPlace_ctl04_rbxContentImage" title="Our Subreddit!" href="https://www.reddit.com/r/goodblox/" style="display:inline-block;cursor:pointer;margin-top:-10px;"><img src="resources/reddit.png" id="img" alt="Our Subreddit!" height="75" width="75" border="0"></a>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
        <div id="UserPlaces_Header">
          <h3>GoodBlox Links</h3>
          <p>Check out our important links that you could use!</p>
        </div>
      </div>

    </div>
    <?php print($GLOBALS['site']->getFooter()); ?>
</div>