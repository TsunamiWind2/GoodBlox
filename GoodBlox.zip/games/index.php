<?php
require '../goodblox/core/config.php';
//c03&4ncfig
$GLOBALS['site'] = new site();
print($GLOBALS['site']->getDependencies(1, "GoodBlox: We're Good", "GoodBlox is a 2007 revival aiming to replicate ROBLOX as it was in 2007!", "lol"));
print($GLOBALS['site']->getHeader(true)); //true - show nav, false - dont show nav
?>
<div id="Body">
    <br>
<b>Notice</b>:  Undefined variable: id in <b>C:\GoodBlox\Website\games\index.php</b> on line <b>41</b><br>
    <h2>Games aren't done yet.</h2>
    <p>Games will be released 7 days before the beta period ends.</p>
</div>
<?php print($GLOBALS['site']->getFooter()); ?>