<?php
//hackyeb
require '../goodblox/core/config.php';
//catal2$35
require '../goodblox/classes/catalog.php';
$GLOBALS['site'] = new site();
print($GLOBALS['site']->getDependencies(1, "GoodBlox: We're Good", "GoodBlox is a 2007 revival aiming to replicate ROBLOX as it was in 2007!", 'og'));
print($GLOBALS['site']->getHeader(true)); //true - show nav, false - dont show nav
//CATALOG, JACK!111
$browse = $_GET['Browse'] ?? 'Featured';
$cat = $_GET['Category'] ?? 'Hats';
$currency = $_GET['Currency'] ?? 'All';
$keyword = $_POST['keyword'] ?? ($_GET['Keyword'] ?? null);
//not done
$catalog = new catalog($browse, $cat, $currency, $keyword);
$page = isset($_GET['Page']) ? max(1, intval($_GET['Page'])) : 1; //max(1, is og)...
//you might dynamic this too idk lol.
$perPage = 20;
$result = $catalog->getCatalog($page, $perPage);
$items = $result['items'];
//some old code from 2023
$totalItems = $result['total'];
$totalPages = ceil($totalItems / $perPage);
//yes, not done
$total = 0;
?>
<div id="Body">
<div id="CatalogContainer">
    <form method="post" id="SearchBar" class="SearchBar">
        <span class="SearchBox"><input name="keyword" maxlength="100" class="TextBox" type="text"></span>
        <span class="SearchButton"><input value="Search" type="submit"></span>
    </form>
    <div class="DisplayFilters">
      <h2>Catalog</h2>
      <div id="BrowseMode">
        <h4>Browse</h4>
        <ul>
          <li><?php if($browse === 'Featured'){ ?><img class="GamesBullet" src="/resources/games_bullet.png" border="0"><b><?php }else{ echo '<a href="/catalog/?Browse=Featured&amp;Category='.$cat.'&amp;Currency='.$currency.'&amp;Keyword='.$keyword.'&amp;Page=1">'; } ?>Featured<?php if($browse === 'Featured'){ ?></b><?php }else{ echo '</a>'; } ?></li>
          <li><?php if($browse === 'ForSale'){ ?><img class="GamesBullet" src="/resources/games_bullet.png" border="0"><b><?php }else{ echo '<a href="/catalog/?Browse=ForSale&amp;Category='.$cat.'&amp;Currency='.$currency.'&amp;Keyword='.$keyword.'&amp;Page=1">'; } ?>For Sale<?php if($browse === 'ForSale'){ ?></b><?php }else{ echo '</a>'; } ?></li>
          <li><?php if($browse === 'BestSelling'){ ?><img class="GamesBullet" src="/resources/games_bullet.png" border="0"><b><?php }else{ echo '<a href="/catalog/?Browse=BestSelling&amp;Category='.$cat.'&amp;Currency='.$currency.'&amp;Keyword='.$keyword.'&amp;Page=1">'; } ?>Best Selling<?php if($browse === 'BestSelling'){ ?></b><?php }else{ echo '</a>'; } ?></li>
          <li><?php if($browse === 'RecentlyUpdated'){ ?><img class="GamesBullet" src="/resources/games_bullet.png" border="0"><b><?php }else{ echo '<a href="/catalog/?Browse=RecentlyUpdated&amp;Category='.$cat.'&amp;Currency='.$currency.'&amp;Keyword='.$keyword.'&amp;Page=1">'; } ?>Recently Updated<?php if($browse === 'RecentlyUpdated'){ ?></b><?php }else{ echo '</a>'; } ?></li>
        </ul>
      </div>
      <div id="Category">
        <h4>Category</h4>
        
            <ul>
            <li><?php if($cat === 'Hats'){ ?><img class="GamesBullet" src="/resources/games_bullet.png" border="0"><b><?php }else{ echo '<a href="/catalog/?Browse=Featured&amp;Category=Hats&amp;Currency=All&amp;Keyword=&amp;Page=1">'; } ?>Hats<?php if($cat === 'Hats'){ ?></b><?php }else{ echo '</a>'; } ?></li>
            <li><?php if($cat === 'Shirts'){ ?><img class="GamesBullet" src="/resources/games_bullet.png" border="0"><b><?php }else{ echo '<a href="/catalog/?Browse=Featured&amp;Category=Shirts&amp;Currency=All&amp;Keyword=&amp;Page=1">'; } ?>Shirts<?php if($cat === 'Shirts'){ ?></b><?php }else{ echo '</a>'; } ?></li>
            </ul>
          
    </div>
          
    </div>
    <div class="Assets">
        <span class="AssetsDisplaySet"><?php echo preg_replace('/(?<!^)([A-Z])/', ' $1', $browse); ?> <?php echo $cat; ?></span>
      <div class="HeaderPager">
                  <span>Page <?php echo $page; ?> of <?php echo $totalPages; ?>:</span>
                      <?php if($page > 1): ?>
                          <a id="ctl00_cphRoblox_HeaderPagerHyperLink_Previous" class="PageSelector" href="?Browse=<?php echo $browse; ?>&Category=<?php echo $cat; ?>&Currency=<?php echo $currency; ?>&Keyword=<?php echo urlencode($keyword); ?>&Page=<?php echo $page-1; ?>"><span class="NavigationIndicators"><<</span> Previous</a>
                      <?php endif; ?>
                      <?php if($page < $totalPages): ?>
                          <a id="ctl00_cphRoblox_HeaderPagerHyperLink_Next" class="PageSelector" href="?Browse=<?php echo $browse; ?>&Category=<?php echo $cat; ?>&Currency=<?php echo $currency; ?>&Keyword=<?php echo urlencode($keyword); ?>&Page=<?php echo $page+1; ?>">Next <span class="NavigationIndicators">&gt;&gt;</span></a>
                      <?php endif; ?>
                  </div>
      <table width="735" cellspacing="0" border="0" align="Center">
  <tbody>
       <?php
       foreach ($items as $item) {
          if ($total % 5 == 0) { 
            echo "<tr>";
          }
          //old
          $stmt = $GLOBALS['pdo']->prepare("SELECT * FROM users WHERE id = :id");
          $stmt->execute(['id' => $item['creator_id']]);
          $creator = $stmt->fetch(PDO::FETCH_ASSOC); 
       ?>
          <td valign="top">
            <div class="Asset">
              <div class="AssetThumbnail">
                <a id="AssetThumbnailHyperLink" title="<?php echo $GLOBALS['site']->cleanOutput($item['name']); ?>" href="/catalog/item?id=<?php echo intval($item['id']); ?>" style="display:inline-block;cursor:pointer;"><img src="/goodblox/images/render/tshirt/<?php echo intval($item['id']); ?>.png?hax=<?php echo time(); ?>" id="img" alt="<?php echo $GLOBALS['site']->cleanOutput($item['name']); ?>" border="0" style="width:120px;height:120px;"></a>
              </div>
              <div class="AssetDetails">
                <div class="AssetName">
              <a id="AssetNameHyperLink" href="/catalog/item?id=<?php echo intval($item['id']); ?>"><?php echo $GLOBALS['site']->cleanOutput($item['name']); ?></a>
            </div>
            <div class="AssetCreator">
              <span class="Label">Creator:</span> 
              <span class="Detail">
                <a id="AssetCreatorHyperLink" href="/users?id=<?php echo intval($creator['id']); ?>"><?php echo $GLOBALS['site']->cleanOutput($creator['username']); ?></a>
              </span>
            </div>
            <?php if($item['bux']){ ?>
                <div class="AssetPrice">
              <span class="PriceInRobux">R$: <?php echo intval($item['bux']); ?></span>
            </div>            <?php } ?> 
              <?php if($item['tix']){ ?>
                <div class="AssetPrice">
              <span class="PriceInTickets">Tx: <?php echo intval($item['tix']); ?></span>
            </div>            <?php } ?>  </div>
          </div>
        </td>
    <?php
    $total++;
    if ($total % 5 == 0) { 
      echo "</tr>";
    }
    }
    //uhhh
    if ($total % 5 != 0) {
    $remaining = 5 - ($total % 5);
    for ($i = 0; $i < $remaining; $i++) {
     echo '<td valign="top"><div class="Asset"></div></td>';
    }
    echo "</tr>";
    } 
    ?>
         
     
</tbody></table>
        <div class="HeaderPager">
                  <span>Page <?php echo $page; ?> of <?php echo $totalPages; ?>:</span>
                      <?php if($page > 1): ?>
                          <a id="ctl00_cphRoblox_HeaderPagerHyperLink_Previous" class="PageSelector" href="?Browse=<?php echo $browse; ?>&Category=<?php echo $cat; ?>&Currency=<?php echo $currency; ?>&Keyword=<?php echo urlencode($keyword); ?>&Page=<?php echo $page-1; ?>"><span class="NavigationIndicators"><<</span> Previous</a>
                      <?php endif; ?>
                      <?php if($page < $totalPages): ?>
                          <a id="ctl00_cphRoblox_HeaderPagerHyperLink_Next" class="PageSelector" href="?Browse=<?php echo $browse; ?>&Category=<?php echo $cat; ?>&Currency=<?php echo $currency; ?>&Keyword=<?php echo urlencode($keyword); ?>&Page=<?php echo $page+1; ?>">Next <span class="NavigationIndicators">&gt;&gt;</span></a>
                      <?php endif; ?>
                    </div>
    </div>
    <div style="clear: both;">
</div>

</div>
 <?php print($GLOBALS['site']->getFooter()); ?>