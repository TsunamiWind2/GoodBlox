<?php
require '../goodblox/core/config.php';
$GLOBALS['site'] = new site();
print($GLOBALS['site']->getDependencies(1, "GoodBlox", "GoodBlox is a 2007 revival aiming to replicate ROBLOX as it was in 2007!", $GLOBALS['baseURL'].'resources/images/logo.png'));
print($GLOBALS['site']->getHeader(true)); //true - show nav, false - dont show nav
?>
<div id="Body">
    <div id="Error">
                    <h2>An error occurred!</h2>
                    <h3>Oh noes! Sorry about that! Just rewind time by going back.</h3>
                    <img src="/resources/errorPage.jpg">
                    <br>
                    <input name="GoBack" value="Rewind Time!" onclick="javascript:window.history.back()" id="GoBack" tabindex="5" class="BigButton" type="submit" style="margin-left: 370px; margin-top: 20px; background-color: #3B88C3">
    </div>

</div>
<?php print($GLOBALS['site']->getFooter()); ?>