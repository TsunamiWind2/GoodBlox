<?php
require '../goodblox/core/config.php';
//c03&4ncfig
$GLOBALS['site'] = new site();
print($GLOBALS['site']->getDependencies(1, "GoodBlox: We're Good", "GoodBlox is a 2007 revival aiming to replicate ROBLOX as it was in 2007!", "lol"));
print($GLOBALS['site']->getHeader(true)); //true - show nav, false - dont show nav
if(!$GLOBALS['user']->isLoggedIn()) {
  header('Location: /login'); //new
  die();
}
//YESSS
$err_e_1 = false;
$err_e_2 = false;
$err_e_3 = false;
//profile settings
if (isset($_POST['ud'])) {
    //profile stuff haha
    $e = trim($_POST['e']); //email
    $bb = trim($_POST['bb']); //blurb
    //ver email
    if($GLOBALS['self']->email !== $e){
      //..ye
      $check = $GLOBALS['pdo']->prepare("SELECT * FROM users WHERE email = :email LIMIT 1");
      $check->execute(['email'=>$e]);
      $check = $check->fetch(PDO::FETCH_OBJ);
      //check email if it exists
      if(empty($e)){
        $err_e_1 = true;
      }
      //./verify(#$2)->a
      if(!filter_var($e, FILTER_VALIDATE_EMAIL)){
        //you can dynamic this jack, --alex
        $err_e_2 = true;  
      }  
      //checkk it
      if($check){
        $err_e_3 = true;
      }
    }
    //success :]
    if(empty($err_e_1) && empty($err_e_2) && empty($err_e_3)){
      //blub
      if (strlen($bb) > 1000) {
        header('Location: /my/profile'); //false
        die();
      }else{
        //ok
        $stmt = $GLOBALS['pdo']->prepare("UPDATE users SET email = ?, blurb = ? WHERE id = ?");
        $stmt->execute([$e, $bb, $GLOBALS['self']->id]);
        header('Location: /my/profile'); //true
        die();
       }
    }
}
?>
<div id="Body">
  <form method="post">
  <div id="EditProfileContainer">
    <h2>Edit Profile</h2>
        <div id="ResetPassword">
      <fieldset title="Reset your password">
        <legend>Change your password</legend>
        <div class="Suggestion">Click the button below to change your password.</div>
        <div class="ResetPasswordRow">
                    &nbsp;<a id="ctl00_cphRoblox_ChangePassword" href="#">Change Password</a></div>
      </fieldset>
        </div>
        <div id="EnterEmail">
        <fieldset title="Update Email Address">
          <legend>Update Email Address</legend>
          <div class="Validators">
            <div><span id="ctl00_cphRoblox_RegularExpressionValidator2" style="color:Red;<?php if(!$err_e_2){ echo 'display:none'; } ?>">Please enter a valid email address.</span></div>
            <div><span id="ctl00_cphRoblox_RequiredFieldValidator1" style="color:Red;<?php if(!$err_e_1){ echo 'display:none'; } ?>">Email is required.</span></div>
            <div><span id="ctl00_cphRoblox_CustomValidatorEmail" style="color:Red;<?php if(!$err_e_3){ echo 'display:none'; } ?>">An account with this email address already exists.</span></div>
          </div>
          <div class="EmailRow">
            <label for="ctl00_cphRoblox_TextBoxEMail" id="ctl00_cphRoblox_LabelEmail" class="Label">Email:</label>&nbsp;<input name="e" type="text" value="<?php echo $GLOBALS['site']->cleanOutput($GLOBALS['self']->email); ?>" id="ctl00_cphRoblox_TextBoxEMail" tabindex="4" class="TextBox">
          </div>
        </fieldset>
    </div>
        <div id="Blurb">
      <fieldset title="Update your personal blurb">
        <legend>Update your personal blurb</legend>
        <div class="Suggestion">
          Describe yourself here (max. 1000 characters).  Make sure not to provide any details that can be used to identify you outside GoodBlox.
        </div>
        <div class="BlurbRow">
          <textarea name="bb" rows="2" cols="20" id="ctl00_cphRoblox_tbBlurb" tabindex="3" class="MultilineTextBox"><?php echo $GLOBALS['site']->cleanOutput($GLOBALS['self']->blurb); ?></textarea>
        </div>
      </fieldset>
        </div>
        <div class="Buttons">
      <input type="submit" value="Update" id="ctl00_cphRoblox_lbSubmit" tabindex="4" name="ud" class="Button" href="#">&nbsp;<a id="ctl00_cphRoblox_lbCancel" tabindex="5" class="Button" href="/my/home">Cancel</a>
        </div>
  </div>
</form>
        </div>
<?php print($GLOBALS['site']->getFooter()); ?>