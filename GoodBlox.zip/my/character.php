<?php
require '../goodblox/core/config.php';
//c03&4ncfig
require '../goodblox/classes/home.php';
$GLOBALS['site'] = new site();
print($GLOBALS['site']->getDependencies(1, "GoodBlox", "GoodBlox is a 2007 revival aiming to replicate ROBLOX as it was in 2007!", "lol"));
print($GLOBALS['site']->getHeader(true)); //true - show nav, false - dont show nav
if(!$GLOBALS['user']->isLoggedIn()) {
  header('Location: /login'); //new
  die();
}
$GLOBALS['home'] = new home(); // my/home page
//doing array for some reason
$GLOBALS['profile'] = $GLOBALS['home']->bro($GLOBALS['self']->id);
//inventory syst%$%m
//hats :)
$hats = $GLOBALS['home']->inv($GLOBALS['profile']['id'], 1);
//shirts
$shirts = $GLOBALS['home']->inv($GLOBALS['profile']['id'], 2);
?>
<div id="Body">
          
    
    
    
    <div style="float: right; width: 230px; padding: 0px 24px 0px">
        <h3>
            Pick Colors</h3>
        <p>
            Click a body part to change its color</p>
        <div id="ctl00_cphRoblox_UpdatePanel1">
  
                <div id="ctl00_cphRoblox_Frame" style="height:236px;width:176px;background-image:url(../resources/CharacterBackdrop.png);">
    
                    <div style="position: relative; margin: 31px 11px">
                        <div style="">
                            <div style="position: absolute; left: 120px; top: 44px; cursor: pointer">
                                <div id="ctl00_cphRoblox_HotButtonRightArm" style="background-color:#4B974A;height:72px;width:32px;">
      
                                
    </div>
                            </div>
                            <div style="position: absolute; left: 40px; top: 44px; cursor: pointer">
                                <div id="ctl00_cphRoblox_HotButtonTorso" style="background-color:#287F46;height:72px;width:72px;">
      
                                    <div style="position: absolute; left: 16px; top: 16px; cursor: pointer">
                                        <img id="ctl00_cphRoblox_ShirtImage" disabled="disabled" src="http://rhodu.k.vu/goodblox/api/scripts/asset/?version=1&amp;id=1" style="height:40px;width:40px;border-width:0px;"></div>
                                
    </div>
                            </div>
                            <div style="position: absolute; left: 0px; top: 44px; cursor: pointer">
                                <div id="ctl00_cphRoblox_HotButtonLeftArm" style="background-color:#4B974A;height:72px;width:32px;">
      
                                
    </div>
                            </div>
                            <div style="position: absolute; left: 58px; top: 0px; cursor: pointer">
                                <div id="ctl00_cphRoblox_HotButtonHead" style="background-color:#F5CD2F;height:36px;width:36px;">
      
                                    <a id="ctl00_cphRoblox_FaceImage" disabled="disabled" onclick="return false" style="display:inline-block;height:36px;width:36px;"><img src="/resources/face_36x36.png" width="36px" border="0" id="img" alt=""></a>
                                
    </div>
                                <div style="position: absolute; left: 0px; top: -40px; cursor: default">
                                    <a id="ctl00_cphRoblox_HatImage" disabled="disabled" title="Blue Baseball Cap" onclick="return false" style="display:inline-block;height:40px;width:40px;"><img src="http://rhodu.k.vu/goodblox/api/scripts/asset/?version=1&amp;id=1" width="36px" border="0" id="img" alt="Blue Baseball Cap"></a></div>
                            </div>
                            <div style="position: absolute; left: 40px; top: 124px; cursor: pointer">
                                <div id="ctl00_cphRoblox_HotButtonLeftLeg" style="background-color:#27462C;height:72px;width:32px;">
      
                                
    </div>
                            </div>
                            <div style="position: absolute; left: 80px; top: 124px; cursor: pointer">
                                <div id="ctl00_cphRoblox_HotButtonRightLeg" style="background-color:#27462C;height:72px;width:32px;">
      
                                
    </div>
                            </div>
                        </div>
                    </div>
                
  </div>
                <a id="ctl00_cphRoblox_LinkButtonTakeShirtOff" href="#">Take Shirt Off</a>
                <a id="ctl00_cphRoblox_LinkButtonTakeOffHat" href="#">Take Hat Off</a>
                <div id="ctl00_cphRoblox_PopupPanelRightLeg" class="popupControl">
    
                    <table id="ctl00_cphRoblox_ColorPickerRightLeg_DataListColors" cellspacing="0" border="0" style="border-width:0px;border-collapse:collapse;">
      <tbody><tr>
        <td>
        <div id="ctl00_cphRoblox_ColorPickerRightLeg_DataListColors_ctl00_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerRightLeg$DataListColors$ctl00$LinkButton1','1')" style="display:inline-block;background-color:#F2F3F2;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerRightLeg_DataListColors_ctl01_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerRightLeg$DataListColors$ctl01$LinkButton1','208')" style="display:inline-block;background-color:#E5E4DE;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerRightLeg_DataListColors_ctl02_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerRightLeg$DataListColors$ctl02$LinkButton1','194')" style="display:inline-block;background-color:#A3A2A4;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerRightLeg_DataListColors_ctl03_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerRightLeg$DataListColors$ctl03$LinkButton1','199')" style="display:inline-block;background-color:#635F61;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerRightLeg_DataListColors_ctl04_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerRightLeg$DataListColors$ctl04$LinkButton1','26')" style="display:inline-block;background-color:#1B2A34;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerRightLeg_DataListColors_ctl05_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerRightLeg$DataListColors$ctl05$LinkButton1','21')" style="display:inline-block;background-color:#C4281B;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerRightLeg_DataListColors_ctl06_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerRightLeg$DataListColors$ctl06$LinkButton1','24')" style="display:inline-block;background-color:#F5CD2F;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerRightLeg_DataListColors_ctl07_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerRightLeg$DataListColors$ctl07$LinkButton1','226')" style="display:inline-block;background-color:#FDEA8C;height:32px;width:32px;">

        </div>
    </td>
      </tr><tr>
        <td>
        <div id="ctl00_cphRoblox_ColorPickerRightLeg_DataListColors_ctl08_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerRightLeg$DataListColors$ctl08$LinkButton1','23')" style="display:inline-block;background-color:#0D69AB;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerRightLeg_DataListColors_ctl09_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerRightLeg$DataListColors$ctl09$LinkButton1','107')" style="display:inline-block;background-color:#008F9B;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerRightLeg_DataListColors_ctl10_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerRightLeg$DataListColors$ctl10$LinkButton1','102')" style="display:inline-block;background-color:#6E99C9;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerRightLeg_DataListColors_ctl11_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerRightLeg$DataListColors$ctl11$LinkButton1','11')" style="display:inline-block;background-color:#80BBDB;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerRightLeg_DataListColors_ctl12_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerRightLeg$DataListColors$ctl12$LinkButton1','45')" style="display:inline-block;background-color:#B4D2E3;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerRightLeg_DataListColors_ctl13_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerRightLeg$DataListColors$ctl13$LinkButton1','135')" style="display:inline-block;background-color:#74869C;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerRightLeg_DataListColors_ctl14_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerRightLeg$DataListColors$ctl14$LinkButton1','106')" style="display:inline-block;background-color:#DA8540;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerRightLeg_DataListColors_ctl15_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerRightLeg$DataListColors$ctl15$LinkButton1','105')" style="display:inline-block;background-color:#E29B3F;height:32px;width:32px;">

        </div>
    </td>
      </tr><tr>
        <td>
        <div id="ctl00_cphRoblox_ColorPickerRightLeg_DataListColors_ctl16_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerRightLeg$DataListColors$ctl16$LinkButton1','141')" style="display:inline-block;background-color:#27462C;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerRightLeg_DataListColors_ctl17_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerRightLeg$DataListColors$ctl17$LinkButton1','28')" style="display:inline-block;background-color:#287F46;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerRightLeg_DataListColors_ctl18_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerRightLeg$DataListColors$ctl18$LinkButton1','37')" style="display:inline-block;background-color:#4B974A;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerRightLeg_DataListColors_ctl19_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerRightLeg$DataListColors$ctl19$LinkButton1','119')" style="display:inline-block;background-color:#A4BD46;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerRightLeg_DataListColors_ctl20_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerRightLeg$DataListColors$ctl20$LinkButton1','29')" style="display:inline-block;background-color:#A1C48B;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerRightLeg_DataListColors_ctl21_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerRightLeg$DataListColors$ctl21$LinkButton1','151')" style="display:inline-block;background-color:#789081;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerRightLeg_DataListColors_ctl22_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerRightLeg$DataListColors$ctl22$LinkButton1','38')" style="display:inline-block;background-color:#A05F34;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerRightLeg_DataListColors_ctl23_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerRightLeg$DataListColors$ctl23$LinkButton1','192')" style="display:inline-block;background-color:#694027;height:32px;width:32px;">

        </div>
    </td>
      </tr><tr>
        <td>
        <div id="ctl00_cphRoblox_ColorPickerRightLeg_DataListColors_ctl24_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerRightLeg$DataListColors$ctl24$LinkButton1','104')" style="display:inline-block;background-color:#6B327B;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerRightLeg_DataListColors_ctl25_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerRightLeg$DataListColors$ctl25$LinkButton1','9')" style="display:inline-block;background-color:#E8BAC7;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerRightLeg_DataListColors_ctl26_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerRightLeg$DataListColors$ctl26$LinkButton1','101')" style="display:inline-block;background-color:#DA8679;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerRightLeg_DataListColors_ctl27_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerRightLeg$DataListColors$ctl27$LinkButton1','5')" style="display:inline-block;background-color:#D7C599;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerRightLeg_DataListColors_ctl28_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerRightLeg$DataListColors$ctl28$LinkButton1','153')" style="display:inline-block;background-color:#957976;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerRightLeg_DataListColors_ctl29_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerRightLeg$DataListColors$ctl29$LinkButton1','217')" style="display:inline-block;background-color:#7C5C45;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerRightLeg_DataListColors_ctl30_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerRightLeg$DataListColors$ctl30$LinkButton1','18')" style="display:inline-block;background-color:#CC8E68;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerRightLeg_DataListColors_ctl31_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerRightLeg$DataListColors$ctl31$LinkButton1','125')" style="display:inline-block;background-color:#EAB891;height:32px;width:32px;">

        </div>
    </td>
      </tr>
    </tbody></table>

                
  </div>
                <div id="ctl00_cphRoblox_PopupPanelLeftLeg" class="popupControl">
    
                    <table id="ctl00_cphRoblox_ColorPickerLeftLeg_DataListColors" cellspacing="0" border="0" style="border-width:0px;border-collapse:collapse;">
      <tbody><tr>
        <td>
        <div id="ctl00_cphRoblox_ColorPickerLeftLeg_DataListColors_ctl00_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerLeftLeg$DataListColors$ctl00$LinkButton1','1')" style="display:inline-block;background-color:#F2F3F2;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerLeftLeg_DataListColors_ctl01_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerLeftLeg$DataListColors$ctl01$LinkButton1','208')" style="display:inline-block;background-color:#E5E4DE;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerLeftLeg_DataListColors_ctl02_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerLeftLeg$DataListColors$ctl02$LinkButton1','194')" style="display:inline-block;background-color:#A3A2A4;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerLeftLeg_DataListColors_ctl03_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerLeftLeg$DataListColors$ctl03$LinkButton1','199')" style="display:inline-block;background-color:#635F61;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerLeftLeg_DataListColors_ctl04_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerLeftLeg$DataListColors$ctl04$LinkButton1','26')" style="display:inline-block;background-color:#1B2A34;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerLeftLeg_DataListColors_ctl05_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerLeftLeg$DataListColors$ctl05$LinkButton1','21')" style="display:inline-block;background-color:#C4281B;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerLeftLeg_DataListColors_ctl06_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerLeftLeg$DataListColors$ctl06$LinkButton1','24')" style="display:inline-block;background-color:#F5CD2F;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerLeftLeg_DataListColors_ctl07_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerLeftLeg$DataListColors$ctl07$LinkButton1','226')" style="display:inline-block;background-color:#FDEA8C;height:32px;width:32px;">

        </div>
    </td>
      </tr><tr>
        <td>
        <div id="ctl00_cphRoblox_ColorPickerLeftLeg_DataListColors_ctl08_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerLeftLeg$DataListColors$ctl08$LinkButton1','23')" style="display:inline-block;background-color:#0D69AB;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerLeftLeg_DataListColors_ctl09_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerLeftLeg$DataListColors$ctl09$LinkButton1','107')" style="display:inline-block;background-color:#008F9B;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerLeftLeg_DataListColors_ctl10_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerLeftLeg$DataListColors$ctl10$LinkButton1','102')" style="display:inline-block;background-color:#6E99C9;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerLeftLeg_DataListColors_ctl11_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerLeftLeg$DataListColors$ctl11$LinkButton1','11')" style="display:inline-block;background-color:#80BBDB;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerLeftLeg_DataListColors_ctl12_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerLeftLeg$DataListColors$ctl12$LinkButton1','45')" style="display:inline-block;background-color:#B4D2E3;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerLeftLeg_DataListColors_ctl13_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerLeftLeg$DataListColors$ctl13$LinkButton1','135')" style="display:inline-block;background-color:#74869C;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerLeftLeg_DataListColors_ctl14_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerLeftLeg$DataListColors$ctl14$LinkButton1','106')" style="display:inline-block;background-color:#DA8540;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerLeftLeg_DataListColors_ctl15_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerLeftLeg$DataListColors$ctl15$LinkButton1','105')" style="display:inline-block;background-color:#E29B3F;height:32px;width:32px;">

        </div>
    </td>
      </tr><tr>
        <td>
        <div id="ctl00_cphRoblox_ColorPickerLeftLeg_DataListColors_ctl16_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerLeftLeg$DataListColors$ctl16$LinkButton1','141')" style="display:inline-block;background-color:#27462C;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerLeftLeg_DataListColors_ctl17_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerLeftLeg$DataListColors$ctl17$LinkButton1','28')" style="display:inline-block;background-color:#287F46;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerLeftLeg_DataListColors_ctl18_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerLeftLeg$DataListColors$ctl18$LinkButton1','37')" style="display:inline-block;background-color:#4B974A;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerLeftLeg_DataListColors_ctl19_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerLeftLeg$DataListColors$ctl19$LinkButton1','119')" style="display:inline-block;background-color:#A4BD46;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerLeftLeg_DataListColors_ctl20_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerLeftLeg$DataListColors$ctl20$LinkButton1','29')" style="display:inline-block;background-color:#A1C48B;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerLeftLeg_DataListColors_ctl21_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerLeftLeg$DataListColors$ctl21$LinkButton1','151')" style="display:inline-block;background-color:#789081;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerLeftLeg_DataListColors_ctl22_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerLeftLeg$DataListColors$ctl22$LinkButton1','38')" style="display:inline-block;background-color:#A05F34;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerLeftLeg_DataListColors_ctl23_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerLeftLeg$DataListColors$ctl23$LinkButton1','192')" style="display:inline-block;background-color:#694027;height:32px;width:32px;">

        </div>
    </td>
      </tr><tr>
        <td>
        <div id="ctl00_cphRoblox_ColorPickerLeftLeg_DataListColors_ctl24_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerLeftLeg$DataListColors$ctl24$LinkButton1','104')" style="display:inline-block;background-color:#6B327B;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerLeftLeg_DataListColors_ctl25_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerLeftLeg$DataListColors$ctl25$LinkButton1','9')" style="display:inline-block;background-color:#E8BAC7;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerLeftLeg_DataListColors_ctl26_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerLeftLeg$DataListColors$ctl26$LinkButton1','101')" style="display:inline-block;background-color:#DA8679;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerLeftLeg_DataListColors_ctl27_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerLeftLeg$DataListColors$ctl27$LinkButton1','5')" style="display:inline-block;background-color:#D7C599;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerLeftLeg_DataListColors_ctl28_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerLeftLeg$DataListColors$ctl28$LinkButton1','153')" style="display:inline-block;background-color:#957976;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerLeftLeg_DataListColors_ctl29_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerLeftLeg$DataListColors$ctl29$LinkButton1','217')" style="display:inline-block;background-color:#7C5C45;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerLeftLeg_DataListColors_ctl30_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerLeftLeg$DataListColors$ctl30$LinkButton1','18')" style="display:inline-block;background-color:#CC8E68;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerLeftLeg_DataListColors_ctl31_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerLeftLeg$DataListColors$ctl31$LinkButton1','125')" style="display:inline-block;background-color:#EAB891;height:32px;width:32px;">

        </div>
    </td>
      </tr>
    </tbody></table>

                
  </div>
                <div id="ctl00_cphRoblox_PopupPanelHead" class="popupControl">
    
                    <table id="ctl00_cphRoblox_ColorPickerHead_DataListColors" cellspacing="0" border="0" style="border-width:0px;border-collapse:collapse;">
      <tbody><tr>
        <td>
        <div id="ctl00_cphRoblox_ColorPickerHead_DataListColors_ctl00_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerHead$DataListColors$ctl00$LinkButton1','1')" style="display:inline-block;background-color:#F2F3F2;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerHead_DataListColors_ctl01_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerHead$DataListColors$ctl01$LinkButton1','208')" style="display:inline-block;background-color:#E5E4DE;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerHead_DataListColors_ctl02_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerHead$DataListColors$ctl02$LinkButton1','194')" style="display:inline-block;background-color:#A3A2A4;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerHead_DataListColors_ctl03_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerHead$DataListColors$ctl03$LinkButton1','199')" style="display:inline-block;background-color:#635F61;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerHead_DataListColors_ctl04_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerHead$DataListColors$ctl04$LinkButton1','26')" style="display:inline-block;background-color:#1B2A34;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerHead_DataListColors_ctl05_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerHead$DataListColors$ctl05$LinkButton1','21')" style="display:inline-block;background-color:#C4281B;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerHead_DataListColors_ctl06_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerHead$DataListColors$ctl06$LinkButton1','24')" style="display:inline-block;background-color:#F5CD2F;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerHead_DataListColors_ctl07_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerHead$DataListColors$ctl07$LinkButton1','226')" style="display:inline-block;background-color:#FDEA8C;height:32px;width:32px;">

        </div>
    </td>
      </tr><tr>
        <td>
        <div id="ctl00_cphRoblox_ColorPickerHead_DataListColors_ctl08_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerHead$DataListColors$ctl08$LinkButton1','23')" style="display:inline-block;background-color:#0D69AB;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerHead_DataListColors_ctl09_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerHead$DataListColors$ctl09$LinkButton1','107')" style="display:inline-block;background-color:#008F9B;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerHead_DataListColors_ctl10_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerHead$DataListColors$ctl10$LinkButton1','102')" style="display:inline-block;background-color:#6E99C9;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerHead_DataListColors_ctl11_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerHead$DataListColors$ctl11$LinkButton1','11')" style="display:inline-block;background-color:#80BBDB;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerHead_DataListColors_ctl12_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerHead$DataListColors$ctl12$LinkButton1','45')" style="display:inline-block;background-color:#B4D2E3;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerHead_DataListColors_ctl13_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerHead$DataListColors$ctl13$LinkButton1','135')" style="display:inline-block;background-color:#74869C;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerHead_DataListColors_ctl14_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerHead$DataListColors$ctl14$LinkButton1','106')" style="display:inline-block;background-color:#DA8540;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerHead_DataListColors_ctl15_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerHead$DataListColors$ctl15$LinkButton1','105')" style="display:inline-block;background-color:#E29B3F;height:32px;width:32px;">

        </div>
    </td>
      </tr><tr>
        <td>
        <div id="ctl00_cphRoblox_ColorPickerHead_DataListColors_ctl16_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerHead$DataListColors$ctl16$LinkButton1','141')" style="display:inline-block;background-color:#27462C;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerHead_DataListColors_ctl17_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerHead$DataListColors$ctl17$LinkButton1','28')" style="display:inline-block;background-color:#287F46;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerHead_DataListColors_ctl18_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerHead$DataListColors$ctl18$LinkButton1','37')" style="display:inline-block;background-color:#4B974A;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerHead_DataListColors_ctl19_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerHead$DataListColors$ctl19$LinkButton1','119')" style="display:inline-block;background-color:#A4BD46;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerHead_DataListColors_ctl20_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerHead$DataListColors$ctl20$LinkButton1','29')" style="display:inline-block;background-color:#A1C48B;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerHead_DataListColors_ctl21_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerHead$DataListColors$ctl21$LinkButton1','151')" style="display:inline-block;background-color:#789081;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerHead_DataListColors_ctl22_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerHead$DataListColors$ctl22$LinkButton1','38')" style="display:inline-block;background-color:#A05F34;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerHead_DataListColors_ctl23_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerHead$DataListColors$ctl23$LinkButton1','192')" style="display:inline-block;background-color:#694027;height:32px;width:32px;">

        </div>
    </td>
      </tr><tr>
        <td>
        <div id="ctl00_cphRoblox_ColorPickerHead_DataListColors_ctl24_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerHead$DataListColors$ctl24$LinkButton1','104')" style="display:inline-block;background-color:#6B327B;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerHead_DataListColors_ctl25_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerHead$DataListColors$ctl25$LinkButton1','9')" style="display:inline-block;background-color:#E8BAC7;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerHead_DataListColors_ctl26_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerHead$DataListColors$ctl26$LinkButton1','101')" style="display:inline-block;background-color:#DA8679;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerHead_DataListColors_ctl27_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerHead$DataListColors$ctl27$LinkButton1','5')" style="display:inline-block;background-color:#D7C599;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerHead_DataListColors_ctl28_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerHead$DataListColors$ctl28$LinkButton1','153')" style="display:inline-block;background-color:#957976;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerHead_DataListColors_ctl29_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerHead$DataListColors$ctl29$LinkButton1','217')" style="display:inline-block;background-color:#7C5C45;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerHead_DataListColors_ctl30_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerHead$DataListColors$ctl30$LinkButton1','18')" style="display:inline-block;background-color:#CC8E68;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerHead_DataListColors_ctl31_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerHead$DataListColors$ctl31$LinkButton1','125')" style="display:inline-block;background-color:#EAB891;height:32px;width:32px;">

        </div>
    </td>
      </tr>
    </tbody></table>

                
  </div>
                <div id="ctl00_cphRoblox_PopupPanelTorso" class="popupControl">
    
                    <table id="ctl00_cphRoblox_ColorPickerTorso_DataListColors" cellspacing="0" border="0" style="border-width:0px;border-collapse:collapse;">
      <tbody><tr>
        <td>
        <div id="ctl00_cphRoblox_ColorPickerTorso_DataListColors_ctl00_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerTorso$DataListColors$ctl00$LinkButton1','1')" style="display:inline-block;background-color:#F2F3F2;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerTorso_DataListColors_ctl01_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerTorso$DataListColors$ctl01$LinkButton1','208')" style="display:inline-block;background-color:#E5E4DE;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerTorso_DataListColors_ctl02_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerTorso$DataListColors$ctl02$LinkButton1','194')" style="display:inline-block;background-color:#A3A2A4;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerTorso_DataListColors_ctl03_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerTorso$DataListColors$ctl03$LinkButton1','199')" style="display:inline-block;background-color:#635F61;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerTorso_DataListColors_ctl04_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerTorso$DataListColors$ctl04$LinkButton1','26')" style="display:inline-block;background-color:#1B2A34;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerTorso_DataListColors_ctl05_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerTorso$DataListColors$ctl05$LinkButton1','21')" style="display:inline-block;background-color:#C4281B;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerTorso_DataListColors_ctl06_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerTorso$DataListColors$ctl06$LinkButton1','24')" style="display:inline-block;background-color:#F5CD2F;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerTorso_DataListColors_ctl07_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerTorso$DataListColors$ctl07$LinkButton1','226')" style="display:inline-block;background-color:#FDEA8C;height:32px;width:32px;">

        </div>
    </td>
      </tr><tr>
        <td>
        <div id="ctl00_cphRoblox_ColorPickerTorso_DataListColors_ctl08_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerTorso$DataListColors$ctl08$LinkButton1','23')" style="display:inline-block;background-color:#0D69AB;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerTorso_DataListColors_ctl09_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerTorso$DataListColors$ctl09$LinkButton1','107')" style="display:inline-block;background-color:#008F9B;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerTorso_DataListColors_ctl10_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerTorso$DataListColors$ctl10$LinkButton1','102')" style="display:inline-block;background-color:#6E99C9;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerTorso_DataListColors_ctl11_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerTorso$DataListColors$ctl11$LinkButton1','11')" style="display:inline-block;background-color:#80BBDB;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerTorso_DataListColors_ctl12_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerTorso$DataListColors$ctl12$LinkButton1','45')" style="display:inline-block;background-color:#B4D2E3;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerTorso_DataListColors_ctl13_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerTorso$DataListColors$ctl13$LinkButton1','135')" style="display:inline-block;background-color:#74869C;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerTorso_DataListColors_ctl14_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerTorso$DataListColors$ctl14$LinkButton1','106')" style="display:inline-block;background-color:#DA8540;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerTorso_DataListColors_ctl15_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerTorso$DataListColors$ctl15$LinkButton1','105')" style="display:inline-block;background-color:#E29B3F;height:32px;width:32px;">

        </div>
    </td>
      </tr><tr>
        <td>
        <div id="ctl00_cphRoblox_ColorPickerTorso_DataListColors_ctl16_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerTorso$DataListColors$ctl16$LinkButton1','141')" style="display:inline-block;background-color:#27462C;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerTorso_DataListColors_ctl17_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerTorso$DataListColors$ctl17$LinkButton1','28')" style="display:inline-block;background-color:#287F46;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerTorso_DataListColors_ctl18_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerTorso$DataListColors$ctl18$LinkButton1','37')" style="display:inline-block;background-color:#4B974A;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerTorso_DataListColors_ctl19_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerTorso$DataListColors$ctl19$LinkButton1','119')" style="display:inline-block;background-color:#A4BD46;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerTorso_DataListColors_ctl20_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerTorso$DataListColors$ctl20$LinkButton1','29')" style="display:inline-block;background-color:#A1C48B;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerTorso_DataListColors_ctl21_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerTorso$DataListColors$ctl21$LinkButton1','151')" style="display:inline-block;background-color:#789081;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerTorso_DataListColors_ctl22_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerTorso$DataListColors$ctl22$LinkButton1','38')" style="display:inline-block;background-color:#A05F34;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerTorso_DataListColors_ctl23_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerTorso$DataListColors$ctl23$LinkButton1','192')" style="display:inline-block;background-color:#694027;height:32px;width:32px;">

        </div>
    </td>
      </tr><tr>
        <td>
        <div id="ctl00_cphRoblox_ColorPickerTorso_DataListColors_ctl24_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerTorso$DataListColors$ctl24$LinkButton1','104')" style="display:inline-block;background-color:#6B327B;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerTorso_DataListColors_ctl25_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerTorso$DataListColors$ctl25$LinkButton1','9')" style="display:inline-block;background-color:#E8BAC7;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerTorso_DataListColors_ctl26_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerTorso$DataListColors$ctl26$LinkButton1','101')" style="display:inline-block;background-color:#DA8679;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerTorso_DataListColors_ctl27_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerTorso$DataListColors$ctl27$LinkButton1','5')" style="display:inline-block;background-color:#D7C599;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerTorso_DataListColors_ctl28_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerTorso$DataListColors$ctl28$LinkButton1','153')" style="display:inline-block;background-color:#957976;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerTorso_DataListColors_ctl29_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerTorso$DataListColors$ctl29$LinkButton1','217')" style="display:inline-block;background-color:#7C5C45;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerTorso_DataListColors_ctl30_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerTorso$DataListColors$ctl30$LinkButton1','18')" style="display:inline-block;background-color:#CC8E68;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerTorso_DataListColors_ctl31_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerTorso$DataListColors$ctl31$LinkButton1','125')" style="display:inline-block;background-color:#EAB891;height:32px;width:32px;">

        </div>
    </td>
      </tr>
    </tbody></table>

                
  </div>
                <div id="ctl00_cphRoblox_PopupPanelLeftArm" class="popupControl">
    
                    <table id="ctl00_cphRoblox_ColorPickerLeftArm_DataListColors" cellspacing="0" border="0" style="border-width:0px;border-collapse:collapse;">
      <tbody><tr>
        <td>
        <div id="ctl00_cphRoblox_ColorPickerLeftArm_DataListColors_ctl00_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerLeftArm$DataListColors$ctl00$LinkButton1','1')" style="display:inline-block;background-color:#F2F3F2;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerLeftArm_DataListColors_ctl01_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerLeftArm$DataListColors$ctl01$LinkButton1','208')" style="display:inline-block;background-color:#E5E4DE;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerLeftArm_DataListColors_ctl02_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerLeftArm$DataListColors$ctl02$LinkButton1','194')" style="display:inline-block;background-color:#A3A2A4;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerLeftArm_DataListColors_ctl03_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerLeftArm$DataListColors$ctl03$LinkButton1','199')" style="display:inline-block;background-color:#635F61;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerLeftArm_DataListColors_ctl04_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerLeftArm$DataListColors$ctl04$LinkButton1','26')" style="display:inline-block;background-color:#1B2A34;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerLeftArm_DataListColors_ctl05_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerLeftArm$DataListColors$ctl05$LinkButton1','21')" style="display:inline-block;background-color:#C4281B;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerLeftArm_DataListColors_ctl06_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerLeftArm$DataListColors$ctl06$LinkButton1','24')" style="display:inline-block;background-color:#F5CD2F;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerLeftArm_DataListColors_ctl07_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerLeftArm$DataListColors$ctl07$LinkButton1','226')" style="display:inline-block;background-color:#FDEA8C;height:32px;width:32px;">

        </div>
    </td>
      </tr><tr>
        <td>
        <div id="ctl00_cphRoblox_ColorPickerLeftArm_DataListColors_ctl08_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerLeftArm$DataListColors$ctl08$LinkButton1','23')" style="display:inline-block;background-color:#0D69AB;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerLeftArm_DataListColors_ctl09_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerLeftArm$DataListColors$ctl09$LinkButton1','107')" style="display:inline-block;background-color:#008F9B;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerLeftArm_DataListColors_ctl10_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerLeftArm$DataListColors$ctl10$LinkButton1','102')" style="display:inline-block;background-color:#6E99C9;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerLeftArm_DataListColors_ctl11_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerLeftArm$DataListColors$ctl11$LinkButton1','11')" style="display:inline-block;background-color:#80BBDB;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerLeftArm_DataListColors_ctl12_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerLeftArm$DataListColors$ctl12$LinkButton1','45')" style="display:inline-block;background-color:#B4D2E3;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerLeftArm_DataListColors_ctl13_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerLeftArm$DataListColors$ctl13$LinkButton1','135')" style="display:inline-block;background-color:#74869C;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerLeftArm_DataListColors_ctl14_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerLeftArm$DataListColors$ctl14$LinkButton1','106')" style="display:inline-block;background-color:#DA8540;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerLeftArm_DataListColors_ctl15_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerLeftArm$DataListColors$ctl15$LinkButton1','105')" style="display:inline-block;background-color:#E29B3F;height:32px;width:32px;">

        </div>
    </td>
      </tr><tr>
        <td>
        <div id="ctl00_cphRoblox_ColorPickerLeftArm_DataListColors_ctl16_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerLeftArm$DataListColors$ctl16$LinkButton1','141')" style="display:inline-block;background-color:#27462C;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerLeftArm_DataListColors_ctl17_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerLeftArm$DataListColors$ctl17$LinkButton1','28')" style="display:inline-block;background-color:#287F46;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerLeftArm_DataListColors_ctl18_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerLeftArm$DataListColors$ctl18$LinkButton1','37')" style="display:inline-block;background-color:#4B974A;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerLeftArm_DataListColors_ctl19_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerLeftArm$DataListColors$ctl19$LinkButton1','119')" style="display:inline-block;background-color:#A4BD46;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerLeftArm_DataListColors_ctl20_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerLeftArm$DataListColors$ctl20$LinkButton1','29')" style="display:inline-block;background-color:#A1C48B;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerLeftArm_DataListColors_ctl21_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerLeftArm$DataListColors$ctl21$LinkButton1','151')" style="display:inline-block;background-color:#789081;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerLeftArm_DataListColors_ctl22_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerLeftArm$DataListColors$ctl22$LinkButton1','38')" style="display:inline-block;background-color:#A05F34;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerLeftArm_DataListColors_ctl23_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerLeftArm$DataListColors$ctl23$LinkButton1','192')" style="display:inline-block;background-color:#694027;height:32px;width:32px;">

        </div>
    </td>
      </tr><tr>
        <td>
        <div id="ctl00_cphRoblox_ColorPickerLeftArm_DataListColors_ctl24_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerLeftArm$DataListColors$ctl24$LinkButton1','104')" style="display:inline-block;background-color:#6B327B;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerLeftArm_DataListColors_ctl25_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerLeftArm$DataListColors$ctl25$LinkButton1','9')" style="display:inline-block;background-color:#E8BAC7;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerLeftArm_DataListColors_ctl26_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerLeftArm$DataListColors$ctl26$LinkButton1','101')" style="display:inline-block;background-color:#DA8679;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerLeftArm_DataListColors_ctl27_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerLeftArm$DataListColors$ctl27$LinkButton1','5')" style="display:inline-block;background-color:#D7C599;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerLeftArm_DataListColors_ctl28_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerLeftArm$DataListColors$ctl28$LinkButton1','153')" style="display:inline-block;background-color:#957976;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerLeftArm_DataListColors_ctl29_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerLeftArm$DataListColors$ctl29$LinkButton1','217')" style="display:inline-block;background-color:#7C5C45;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerLeftArm_DataListColors_ctl30_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerLeftArm$DataListColors$ctl30$LinkButton1','18')" style="display:inline-block;background-color:#CC8E68;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerLeftArm_DataListColors_ctl31_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerLeftArm$DataListColors$ctl31$LinkButton1','125')" style="display:inline-block;background-color:#EAB891;height:32px;width:32px;">

        </div>
    </td>
      </tr>
    </tbody></table>

                
  </div>
                <div id="ctl00_cphRoblox_PopupPanelRightArm" class="popupControl">
    
                    <table id="ctl00_cphRoblox_ColorPickerRightArm_DataListColors" cellspacing="0" border="0" style="border-width:0px;border-collapse:collapse;">
      <tbody><tr>
        <td>
        <div id="ctl00_cphRoblox_ColorPickerRightArm_DataListColors_ctl00_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerRightArm$DataListColors$ctl00$LinkButton1','1')" style="display:inline-block;background-color:#F2F3F2;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerRightArm_DataListColors_ctl01_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerRightArm$DataListColors$ctl01$LinkButton1','208')" style="display:inline-block;background-color:#E5E4DE;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerRightArm_DataListColors_ctl02_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerRightArm$DataListColors$ctl02$LinkButton1','194')" style="display:inline-block;background-color:#A3A2A4;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerRightArm_DataListColors_ctl03_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerRightArm$DataListColors$ctl03$LinkButton1','199')" style="display:inline-block;background-color:#635F61;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerRightArm_DataListColors_ctl04_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerRightArm$DataListColors$ctl04$LinkButton1','26')" style="display:inline-block;background-color:#1B2A34;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerRightArm_DataListColors_ctl05_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerRightArm$DataListColors$ctl05$LinkButton1','21')" style="display:inline-block;background-color:#C4281B;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerRightArm_DataListColors_ctl06_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerRightArm$DataListColors$ctl06$LinkButton1','24')" style="display:inline-block;background-color:#F5CD2F;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerRightArm_DataListColors_ctl07_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerRightArm$DataListColors$ctl07$LinkButton1','226')" style="display:inline-block;background-color:#FDEA8C;height:32px;width:32px;">

        </div>
    </td>
      </tr><tr>
        <td>
        <div id="ctl00_cphRoblox_ColorPickerRightArm_DataListColors_ctl08_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerRightArm$DataListColors$ctl08$LinkButton1','23')" style="display:inline-block;background-color:#0D69AB;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerRightArm_DataListColors_ctl09_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerRightArm$DataListColors$ctl09$LinkButton1','107')" style="display:inline-block;background-color:#008F9B;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerRightArm_DataListColors_ctl10_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerRightArm$DataListColors$ctl10$LinkButton1','102')" style="display:inline-block;background-color:#6E99C9;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerRightArm_DataListColors_ctl11_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerRightArm$DataListColors$ctl11$LinkButton1','11')" style="display:inline-block;background-color:#80BBDB;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerRightArm_DataListColors_ctl12_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerRightArm$DataListColors$ctl12$LinkButton1','45')" style="display:inline-block;background-color:#B4D2E3;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerRightArm_DataListColors_ctl13_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerRightArm$DataListColors$ctl13$LinkButton1','135')" style="display:inline-block;background-color:#74869C;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerRightArm_DataListColors_ctl14_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerRightArm$DataListColors$ctl14$LinkButton1','106')" style="display:inline-block;background-color:#DA8540;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerRightArm_DataListColors_ctl15_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerRightArm$DataListColors$ctl15$LinkButton1','105')" style="display:inline-block;background-color:#E29B3F;height:32px;width:32px;">

        </div>
    </td>
      </tr><tr>
        <td>
        <div id="ctl00_cphRoblox_ColorPickerRightArm_DataListColors_ctl16_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerRightArm$DataListColors$ctl16$LinkButton1','141')" style="display:inline-block;background-color:#27462C;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerRightArm_DataListColors_ctl17_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerRightArm$DataListColors$ctl17$LinkButton1','28')" style="display:inline-block;background-color:#287F46;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerRightArm_DataListColors_ctl18_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerRightArm$DataListColors$ctl18$LinkButton1','37')" style="display:inline-block;background-color:#4B974A;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerRightArm_DataListColors_ctl19_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerRightArm$DataListColors$ctl19$LinkButton1','119')" style="display:inline-block;background-color:#A4BD46;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerRightArm_DataListColors_ctl20_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerRightArm$DataListColors$ctl20$LinkButton1','29')" style="display:inline-block;background-color:#A1C48B;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerRightArm_DataListColors_ctl21_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerRightArm$DataListColors$ctl21$LinkButton1','151')" style="display:inline-block;background-color:#789081;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerRightArm_DataListColors_ctl22_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerRightArm$DataListColors$ctl22$LinkButton1','38')" style="display:inline-block;background-color:#A05F34;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerRightArm_DataListColors_ctl23_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerRightArm$DataListColors$ctl23$LinkButton1','192')" style="display:inline-block;background-color:#694027;height:32px;width:32px;">

        </div>
    </td>
      </tr><tr>
        <td>
        <div id="ctl00_cphRoblox_ColorPickerRightArm_DataListColors_ctl24_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerRightArm$DataListColors$ctl24$LinkButton1','104')" style="display:inline-block;background-color:#6B327B;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerRightArm_DataListColors_ctl25_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerRightArm$DataListColors$ctl25$LinkButton1','9')" style="display:inline-block;background-color:#E8BAC7;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerRightArm_DataListColors_ctl26_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerRightArm$DataListColors$ctl26$LinkButton1','101')" style="display:inline-block;background-color:#DA8679;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerRightArm_DataListColors_ctl27_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerRightArm$DataListColors$ctl27$LinkButton1','5')" style="display:inline-block;background-color:#D7C599;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerRightArm_DataListColors_ctl28_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerRightArm$DataListColors$ctl28$LinkButton1','153')" style="display:inline-block;background-color:#957976;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerRightArm_DataListColors_ctl29_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerRightArm$DataListColors$ctl29$LinkButton1','217')" style="display:inline-block;background-color:#7C5C45;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerRightArm_DataListColors_ctl30_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerRightArm$DataListColors$ctl30$LinkButton1','18')" style="display:inline-block;background-color:#CC8E68;height:32px;width:32px;">

        </div>
    </td><td>
        <div id="ctl00_cphRoblox_ColorPickerRightArm_DataListColors_ctl31_LinkButton1" class="ColorPickerItem" onclick="__doPostBack('ctl00$cphRoblox$ColorPickerRightArm$DataListColors$ctl31$LinkButton1','125')" style="display:inline-block;background-color:#EAB891;height:32px;width:32px;">

        </div>
    </td>
      </tr>
    </tbody></table>

                
  </div>
                
                
                
                
                
                
            
</div>
    </div>
    <div>
        <h3>
            Pick a Shirt</h3>
        <div id="ctl00_cphRoblox_UpdatePanel2">
  
                <span id="ctl00_cphRoblox_DataListShirts"><span>
                        <p>
                            Click one of your shirts to wear it</p>
                    </span><?php if (!empty($shirts)){ ?>
                         <?php
                         //shirts inventory
                        foreach ($shirts as $i => $shirt){ ?><span>
                        <div style="display: inline" class="ColorPickerItem">
                            <a id="ctl00_cphRoblox_DataListShirts_ctl01_ImageButtonPickShirt" title=":}" onclick="#" style="display:inline-block;height:96px;width:96px;cursor:pointer;"><img src="http://rhodu.k.vu/goodblox/api/scripts/asset/?version=1&amp;id=1" border="0" id="img" alt=":}"></a>
                        </div>
                    </span><?php }  }else{ echo '<span>
                        <div style="display: inline">
                            <span style="display:inline-block;height:96px;width:230px;">Yo do not yet have any GOODBLOX shirts.</span>
                        </div>
                    </span>'; } ?></span>
            
</div>
        <h3>
            ... or Upload Your Shirt</h3>
        <p>
            Enter an image file in the box below and then click "Wear It!"</p>
        <p>
            <input type="file" name="ctl00$cphRoblox$ShirtGraphicUpload" id="ctl00_cphRoblox_ShirtGraphicUpload"></p>
        <p>
            <input type="submit" name="ctl00$cphRoblox$ButtonWearShirt" value="Wear It!" id="ctl00_cphRoblox_ButtonWearShirt"></p>
    </div>
    <div>
        <h3>
            Pick a Hat</h3>
        <div id="ctl00_cphRoblox_UpdatePanel3">
  
                <span id="ctl00_cphRoblox_DataListHats"><span>
                        <p>
                            Click one of your hats to wear it or
                            <a id="ctl00_cphRoblox_DataListHats_ctl00_HyperLink1" href="../Catalog.aspx?m=ForSale&amp;c=8">buy a hat</a>!</p>
                    </span><?php if (!empty($hats)){ ?>
                         <?php
                         //shirts inventory
                        foreach ($hats as $i => $hat){ ?><span>
                        <div style="display: inline" class="ColorPickerItem">
                            <a id="ctl00_cphRoblox_DataListHats_ctl02_ImageButtonPickHat" title="Bluesteel Gift of Long Years" onclick="javascript:__doPostBack('ctl00$cphRoblox$DataListHats$ctl02$ImageButtonPickHat','')" style="display:inline-block;height:96px;width:96px;cursor:pointer;"><img src="http://t2.roblox.com:80/c4d4459cc27f3b830b61824a602a5634" border="0" id="img" alt="Bluesteel Gift of Long Years"></a>
                        </div>
                    </span><?php }  }else{ echo '<span>
                        <div style="display: inline">
                            <span style="display:inline-block;height:96px;width:230px;">Yo do not yet have any GOODBLOX hats.</span>
                        </div>
                    </span>'; } ?></span>
            


        </div>
<?php print($GLOBALS['site']->getFooter()); ?>