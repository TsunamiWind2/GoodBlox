<?php
//yeahooo 
include('../err/index.php'); //error page for this one
?>