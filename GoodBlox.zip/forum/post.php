<?php
require '../goodblox/core/config.php';
//fo34ums
require '../goodblox/classes/forum.php';
$GLOBALS['site'] = new site();
print($GLOBALS['site']->getDependencies(1, "GoodBlox: We're Good", "GoodBlox is a 2007 revival aiming to replicate ROBLOX as it was in 2007!", $GLOBALS['baseURL'].'resources/images/logo.png'));
print($GLOBALS['site']->getHeader(true)); //true - show nav, false - dont show nav
//FORUMS!!
$forum = new forum();
//topics
$id = intval($_GET['id']) ?? 0;
?>
<link rel="stylesheet" type="text/css" href="../resources/forum.css">
<div id="Body">
        <table width="100%" cellspacing="0" cellpadding="0" border="0">
          <tbody>
            <tr>
              <td>
              </td>
            </tr>
            <tr valign="bottom">
              <td>
                <table width="100%" height="100%" cellspacing="0" cellpadding="0" border="0">
                  <tbody>
                    <tr valign="top">
                      <!-- left column -->
                      <td>&nbsp; &nbsp; &nbsp;</td>
                      <!-- center column -->
                      <td class="CenterColumn" width="95%">
                        <br>
                        <span>
                          <table width="100%" cellspacing="1" cellpadding="0">
                            <tbody>
                              <tr>
                                <td valign="middle" align="right">
                                  <a class="menuTextLink" href="/web/20180610052214/https://goodblox.com/forum"><img src="/web/20180610052214im_/https://goodblox.com/resources/icon_mini_home.gif" border="0">Home &nbsp;</a>
                                </td>
                              </tr>
                            </tbody>
                          </table>
                        </span>
                  <span>
    <table width="100%" cellpadding="0">
      <tbody><tr>
        <td colspan="2" align="left">                                
      <span>
        <table width="100%" cellspacing="0" cellpadding="0">
          <tbody>
            <tr>
              <td align="left" width="1px" valign="top">
                <nobr>
                  <a class="linkMenuSink" href="/web/20180610052214/https://goodblox.com/forum">GoodBlox Forum</a>
                </nobr>
              </td>
              <td class="popupMenuSink" align="left" width="1px" valign="top">
                <nobr>
                  <span class="normalTextSmallBold">&nbsp;&gt;</span>
                  <a class="linkMenuSink" href="http://web.archive.org/web/20180610052214/https://goodblox.com/forum/sfg?id=1">GoodBlox</a>
                </nobr>
              </td>

              <td class="popupMenuSink" align="left" width="1px" valign="top">
                <nobr>
                  <span class="normalTextSmallBold">&nbsp;&gt;</span>
                  <a class="linkMenuSink" href="http://web.archive.org/web/20180610052214/https://goodblox.com/forum/sf?id=1">General Discussion</a>
                </nobr>
              </td>

              <td class="popupMenuSink" width="1px" valign="top" align="left">
                <nobr>
                  <span class="normalTextSmallBold">&nbsp;&gt;</span>
                  <a class="linkMenuSink" href="/web/20180610052214/https://goodblox.com/forum/post?id=3">Welcome to the GoodBlox Forums!</a>
                </nobr>
              </td>

              <td width="*" valign="top" align="left">&nbsp;</td>
            </tr>
          </tbody>
        </table>

        <span></span>
      </span></td>
      </tr>
      <tr>
        <td colspan="2" align="left">&nbsp;
        </td>
      </tr>
      <tr>
        <td align="left" valign="top">
          <span class="normalTextSmallBold"></span>
        </td>
          <td align="right" valign="bottom"><span class="normalTextSmallBold">Display using: </span>
          <select>
            <option selected="selected" value="0">Oldest to newest</option>
            <option value="1">Newest to oldest</option>
          </select>
        </td>
      </tr>
      <tr>
        <td colspan="2">
          <table class="tableBorder" cellspacing="1" width="100%" cellpadding="0" border="0">
        <tbody>
          <tr>
          <td class="forumHeaderBackgroundAlternate" colspan="2" height="20"><table cellspacing="0" width="100%" cellpadding="0" border="0">
            <tbody><tr>
              <td align="left"></td><td align="right"><a class="linkSmallBold" href="http://web.archive.org/web/20180610052214/https://goodblox.com/forum/post?id=2">Previous Thread</a>&nbsp;<span class="normalTextSmallBold">::</span>&nbsp;<a class="linkSmallBold" href="http://web.archive.org/web/20180610052214/https://goodblox.com/forum/post?id=4">Next Thread</a>&nbsp;</td>
            </tr>
          </tbody></table></td>
        </tr><tr>
          <th class="tableHeaderText" align="left" width="100" height="25">&nbsp;Author</th><th class="tableHeaderText" align="left" width="85%">&nbsp;Thread: Welcome to the GoodBlox Forums!</th>
        </tr>
        <tr id="p3">
          <td class="forumRow" width="150" valign="top" nowrap="nowrap">
            <table border="0">
              <tbody>
              <tr>
              <td>
                                  <img src="/web/20180610052214im_/https://goodblox.com/resources/OnlineStatusIndicator_IsOffline.gif" alt="Keanu73 is not online. Last active: 05/06/2018 05:51:02 AM" border="0">
                                <a class="normalTextSmallBold" href="/web/20180610052214/https://goodblox.com/users?id=2">Keanu73</a>
                <br>
              </td>
            </tr>
            <tr>
              <td>
                <a href="/web/20180610052214/https://goodblox.com/users?id=2">
                  <img src="http://web.archive.org/web/20180610052214im_/https://cdn.goodblox.com/content/renders/avatars/others/2-others.png?hax=1234" style="height:64px;width:64px;" border="0">
                </a>
              </td>
            </tr><tr>
              <td><img src="/web/20180610052214im_/https://goodblox.com/resources/users_moderator.gif" alt="Forum Moderator" border="0"></td>
            </tr><tr>
              <td><span class="normalTextSmaller"><b>Joined: </b>18 Dec 2007</span></td>
            </tr><tr>
              <td><span class="normalTextSmaller"><b>Total Posts: </b>22</span></td>
            </tr><tr>
              <td>&nbsp;</td>
            </tr>
            </tbody>
          </table>
        </td>
    <td class="forumRow" valign="top"><table cellspacing="0" width="100%" cellpadding="3" border="0">
            <tbody><tr>
              <td class="forumRowHighlight"><span class="normalTextSmallBold">Welcome to the GoodBlox Forums!</span><br><span class="normalTextSmaller"> Posted: </span><span class="normalTextSmaller">19 Feb 2018 05:08 PM</span></td>
            </tr><tr>
              <td colspan="2"><span class="normalTextSmall">A place to socialize, chat, and just talk in general.</span>
              </td>
            </tr><tr>
              <td colspan="2"><span class="normalTextSmaller"></span></td>
            </tr><tr>
              <td height="2"></td>
            </tr><tr>
              <td colspan="2">
                                <a href="/web/20180610052214/https://goodblox.com/report/forumpost?id=3&amp;top" style="text-decoration: none;">Report Abuse</a>
              </td>
            </tr>
          </tbody></table></td>
        </tr>
                        <tr id="r138">
          <td class="forumAlternate" valign="top" nowrap="nowrap"><table border="0">
            <tbody><tr>
              <td>
                                  <img src="/web/20180610052214im_/https://goodblox.com/resources/OnlineStatusIndicator_IsOffline.gif" alt="pranked is not online. Last active: 05/05/2018 09:07:45 PM" border="0">
                                <a class="normalTextSmallBold" href="/web/20180610052214/https://goodblox.com/users?id=71">pranked</a>
                <br>
              </td>
            </tr><tr>
              <td>
                <a href="/web/20180610052214/https://goodblox.com/users?id=71">
                  <img src="http://web.archive.org/web/20180610052214im_/https://cdn.goodblox.com/content/renders/avatars/others/71-others.png?hax=1234" style="height:64px;width:64px;" border="0">
                </a>
              </td>
            </tr><tr>
              <td><span class="normalTextSmaller"><b>Joined:</b> 12 Mar 2018</span></td>
            </tr><tr>
              <td><span class="normalTextSmaller"><b>Total Posts: </b>9</span></td>
            </tr><tr>
              <td>&nbsp;</td>
            </tr>
          </tbody></table></td><td class="forumAlternate" valign="top"><table cellspacing="0" width="100%" cellpadding="3" border="0">
            <tbody><tr>
              <td class="forumRowHighlight">
                <span class="normalTextSmallBold">Re: Welcome to the GoodBlox Forums!</span><br><span class="normalTextSmaller"> Posted: </span><span class="normalTextSmaller">13 Mar 2018 09:26 PM</span></td>
            </tr><tr>
              <td colspan="2"><span class="normalTextSmall">hey im a hackerman</span></td>
            </tr><tr>
              <td colspan="2"><span class="normalTextSmaller"></span></td>
            </tr><tr>
              <td height="2"></td>
            </tr><tr>
              <td colspan="2">
                                <a href="/web/20180610052214/https://goodblox.com/forum/reply?to=138&amp;rep" style="text-decoration: none;">
                  <img src="/web/20180610052214im_/https://goodblox.com/resources/newpost.gif" border="0">
                </a>
                                <a href="/web/20180610052214/https://goodblox.com/report/forumpost?id=138&amp;rep" style="text-decoration: none;">Report Abuse</a>
                              </td>
            </tr>
          </tbody></table></td>
        </tr>
                        <tr id="r139">
          <td class="forumRow" valign="top" nowrap="nowrap"><table border="0">
            <tbody><tr>
              <td>
                                  <img src="/web/20180610052214im_/https://goodblox.com/resources/OnlineStatusIndicator_IsOffline.gif" alt="pranked is not online. Last active: 05/05/2018 09:07:45 PM" border="0">
                                <a class="normalTextSmallBold" href="/web/20180610052214/https://goodblox.com/users?id=71">pranked</a>
                <br>
              </td>
            </tr><tr>
              <td>
                <a href="/web/20180610052214/https://goodblox.com/users?id=71">
                  <img src="http://web.archive.org/web/20180610052214im_/https://cdn.goodblox.com/content/renders/avatars/others/71-others.png?hax=1234" style="height:64px;width:64px;" border="0">
                </a>
              </td>
            </tr><tr>
              <td><span class="normalTextSmaller"><b>Joined:</b> 12 Mar 2018</span></td>
            </tr><tr>
              <td><span class="normalTextSmaller"><b>Total Posts: </b>9</span></td>
            </tr><tr>
              <td>&nbsp;</td>
            </tr>
          </tbody></table></td><td class="forumRow" valign="top"><table cellspacing="0" width="100%" cellpadding="3" border="0">
            <tbody><tr>
              <td class="forumRowHighlight">
                <span class="normalTextSmallBold">Re: Welcome to the GoodBlox Forums!</span><br><span class="normalTextSmaller"> Posted: </span><span class="normalTextSmaller">13 Mar 2018 09:28 PM</span></td>
            </tr><tr>
              <td colspan="2"><span class="normalTextSmall">a</span></td>
            </tr><tr>
              <td colspan="2"><span class="normalTextSmaller"></span></td>
            </tr><tr>
              <td height="2"></td>
            </tr><tr>
              <td colspan="2">
                                <a href="/web/20180610052214/https://goodblox.com/forum/reply?to=139&amp;rep" style="text-decoration: none;">
                  <img src="/web/20180610052214im_/https://goodblox.com/resources/newpost.gif" border="0">
                </a>
                                <a href="/web/20180610052214/https://goodblox.com/report/forumpost?id=139&amp;rep" style="text-decoration: none;">Report Abuse</a>
                              </td>
            </tr>
          </tbody></table></td>
        </tr>
                        <tr id="r140">
          <td class="forumAlternate" valign="top" nowrap="nowrap"><table border="0">
            <tbody><tr>
              <td>
                                  <img src="/web/20180610052214im_/https://goodblox.com/resources/OnlineStatusIndicator_IsOffline.gif" alt="Godzilla is not online. Last active: 10/06/2018 01:18:51 AM" border="0">
                                <a class="normalTextSmallBold" href="/web/20180610052214/https://goodblox.com/users?id=32">Godzilla</a>
                <br>
              </td>
            </tr><tr>
              <td>
                <a href="/web/20180610052214/https://goodblox.com/users?id=32">
                  <img src="http://web.archive.org/web/20180610052214im_/https://cdn.goodblox.com/content/renders/avatars/others/32-others.png?hax=1234" style="height:64px;width:64px;" border="0">
                </a>
              </td>
            </tr><tr>
              <td><span class="normalTextSmaller"><b>Joined:</b> 18 Feb 2018</span></td>
            </tr><tr>
              <td><span class="normalTextSmaller"><b>Total Posts: </b>12</span></td>
            </tr><tr>
              <td>&nbsp;</td>
            </tr>
          </tbody></table></td><td class="forumAlternate" valign="top"><table cellspacing="0" width="100%" cellpadding="3" border="0">
            <tbody><tr>
              <td class="forumRowHighlight">
                <span class="normalTextSmallBold">Re: Welcome to the GoodBlox Forums!</span><br><span class="normalTextSmaller"> Posted: </span><span class="normalTextSmaller">13 Mar 2018 09:29 PM</span></td>
            </tr><tr>
              <td colspan="2"><span class="normalTextSmall">cloud</span></td>
            </tr><tr>
              <td colspan="2"><span class="normalTextSmaller"></span></td>
            </tr><tr>
              <td height="2"></td>
            </tr><tr>
              <td colspan="2">
                                <a href="/web/20180610052214/https://goodblox.com/forum/reply?to=140&amp;rep" style="text-decoration: none;">
                  <img src="/web/20180610052214im_/https://goodblox.com/resources/newpost.gif" border="0">
                </a>
                                <a href="/web/20180610052214/https://goodblox.com/report/forumpost?id=140&amp;rep" style="text-decoration: none;">Report Abuse</a>
                              </td>
            </tr>
          </tbody></table></td>
        </tr>
                        <tr id="r141">
          <td class="forumRow" valign="top" nowrap="nowrap"><table border="0">
            <tbody><tr>
              <td>
                                  <img src="/web/20180610052214im_/https://goodblox.com/resources/OnlineStatusIndicator_IsOffline.gif" alt="pranked is not online. Last active: 05/05/2018 09:07:45 PM" border="0">
                                <a class="normalTextSmallBold" href="/web/20180610052214/https://goodblox.com/users?id=71">pranked</a>
                <br>
              </td>
            </tr><tr>
              <td>
                <a href="/web/20180610052214/https://goodblox.com/users?id=71">
                  <img src="http://web.archive.org/web/20180610052214im_/https://cdn.goodblox.com/content/renders/avatars/others/71-others.png?hax=1234" style="height:64px;width:64px;" border="0">
                </a>
              </td>
            </tr><tr>
              <td><span class="normalTextSmaller"><b>Joined:</b> 12 Mar 2018</span></td>
            </tr><tr>
              <td><span class="normalTextSmaller"><b>Total Posts: </b>9</span></td>
            </tr><tr>
              <td>&nbsp;</td>
            </tr>
          </tbody></table></td><td class="forumRow" valign="top"><table cellspacing="0" width="100%" cellpadding="3" border="0">
            <tbody><tr>
              <td class="forumRowHighlight">
                <span class="normalTextSmallBold">Re: Welcome to the GoodBlox Forums!</span><br><span class="normalTextSmaller"> Posted: </span><span class="normalTextSmaller">13 Mar 2018 09:30 PM</span></td>
            </tr><tr>
              <td colspan="2"><span class="normalTextSmall">n</span></td>
            </tr><tr>
              <td colspan="2"><span class="normalTextSmaller"></span></td>
            </tr><tr>
              <td height="2"></td>
            </tr><tr>
              <td colspan="2">
                                <a href="/web/20180610052214/https://goodblox.com/forum/reply?to=141&amp;rep" style="text-decoration: none;">
                  <img src="/web/20180610052214im_/https://goodblox.com/resources/newpost.gif" border="0">
                </a>
                                <a href="/web/20180610052214/https://goodblox.com/report/forumpost?id=141&amp;rep" style="text-decoration: none;">Report Abuse</a>
                              </td>
            </tr>
          </tbody></table></td>
        </tr>
                        <tr id="r143">
          <td class="forumAlternate" valign="top" nowrap="nowrap"><table border="0">
            <tbody><tr>
              <td>
                                  <img src="/web/20180610052214im_/https://goodblox.com/resources/OnlineStatusIndicator_IsOffline.gif" alt="rhyex is not online. Last active: 08/06/2018 01:48:22 AM" border="0">
                                <a class="normalTextSmallBold" href="/web/20180610052214/https://goodblox.com/users?id=11">rhyex</a>
                <br>
              </td>
            </tr><tr>
              <td>
                <a href="/web/20180610052214/https://goodblox.com/users?id=11">
                  <img src="http://web.archive.org/web/20180610052214im_/https://cdn.goodblox.com/content/renders/avatars/others/11-others.png?hax=1234" style="height:64px;width:64px;" border="0">
                </a>
              </td>
            </tr><tr>
              <td><span class="normalTextSmaller"><b>Joined:</b> 17 Feb 2018</span></td>
            </tr><tr>
              <td><span class="normalTextSmaller"><b>Total Posts: </b>3</span></td>
            </tr><tr>
              <td>&nbsp;</td>
            </tr>
          </tbody></table></td><td class="forumAlternate" valign="top"><table cellspacing="0" width="100%" cellpadding="3" border="0">
            <tbody><tr>
              <td class="forumRowHighlight">
                <span class="normalTextSmallBold">Re: Welcome to the GoodBlox Forums!</span><br><span class="normalTextSmaller"> Posted: </span><span class="normalTextSmaller">13 Mar 2018 09:31 PM</span></td>
            </tr><tr>
              <td colspan="2"><span class="normalTextSmall">hey I don't care h</span></td>
            </tr><tr>
              <td colspan="2"><span class="normalTextSmaller"></span></td>
            </tr><tr>
              <td height="2"></td>
            </tr><tr>
              <td colspan="2">
                                <a href="/web/20180610052214/https://goodblox.com/forum/reply?to=143&amp;rep" style="text-decoration: none;">
                  <img src="/web/20180610052214im_/https://goodblox.com/resources/newpost.gif" border="0">
                </a>
                                <a href="/web/20180610052214/https://goodblox.com/report/forumpost?id=143&amp;rep" style="text-decoration: none;">Report Abuse</a>
                              </td>
            </tr>
          </tbody></table></td>
        </tr>
                  <tr><td class="forumHeaderBackgroundAlternate" colspan="2" height="20"><table cellspacing="0" width="100%" cellpadding="0" border="0">
            <tbody>
              <tr>
              <td align="left"></td><td align="right"><a class="linkSmallBold" href="http://web.archive.org/web/20180610052214/https://goodblox.com/forum/post?id=2">Previous Thread</a>&nbsp;<span class="normalTextSmallBold">::</span>&nbsp;<a class="linkSmallBold" href="http://web.archive.org/web/20180610052214/https://goodblox.com/forum/post?id=4">Next Thread</a>&nbsp;</td>
              </tr>
            </tbody></table>
          </td>
          </tr>
      </tbody></table>
      <span>
        <table cellspacing="0" width="100%" cellpadding="0" border="0">
        <tbody><tr>
          <td>
            <span class="normalTextSmallBold">Page 1 of 1</span>
          </td>
          <td align="right">
            <span>
                <span class="normalTextSmallBold">Goto to page: </span>            </span>
          </td>
        </tr>
      </tbody>
    </table>
  </span>
</td>
      </tr>
      <tr>
        <td colspan="2">&nbsp;</td>
      </tr>
      <tr>
        <td colspan="2" align="left">

        </td>
      </tr>
      <tr>
        <td colspan="2" align="left">
        <span>
      <table cellspacing="0" width="100%" cellpadding="0">
        <tbody><tr>
          <td align="left" width="1px" valign="top">
            <nobr>
              <a class="linkMenuSink" href="/web/20180610052214/https://goodblox.com/forum">GoodBlox Forum</a>
            </nobr>
          </td>
          <td class="popupMenuSink" align="left" width="1px" valign="top">
            <nobr>
              <span class="normalTextSmallBold">&nbsp;&gt;</span>
              <a class="linkMenuSink" href="http://web.archive.org/web/20180610052214/https://goodblox.com/forum/sfg?id=1">GoodBlox</a>
            </nobr>
          </td>

          <td class="popupMenuSink" align="left" width="1px" valign="top">
            <nobr>
              <span class="normalTextSmallBold">&nbsp;&gt;</span>
              <a class="linkMenuSink" href="http://web.archive.org/web/20180610052214/https://goodblox.com/forum/sf?id=1">General Discussion</a>
            </nobr>
          </td>

          <td class="popupMenuSink" align="left" width="1px" valign="top">
            <nobr>
              <span class="normalTextSmallBold">&nbsp;&gt;</span>
              <a class="linkMenuSink" href="/web/20180610052214/https://goodblox.com/forum/post?id=3">Welcome to the GoodBlox Forums!</a>
            </nobr>
          </td>

          <td align="left" width="*" valign="top">&nbsp;</td>
        </tr>
      </tbody></table>

      <span></span></span>
        </td>
      </tr>
      </tbody></table>
</span>
                </td>

                <td class="CenterColumn">&nbsp;&nbsp;&nbsp;</td>
                <!-- right margin -->
                <td class="RightColumn">&nbsp;&nbsp;&nbsp;</td>
                
              </tr>
            </tbody></table>
          </td>
        </tr>
      </tbody></table>

        </div>