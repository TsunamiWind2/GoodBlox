<?php
require '../goodblox/core/config.php';
//fo34ums
require '../goodblox/classes/forum.php';
$GLOBALS['site'] = new site();
print($GLOBALS['site']->getDependencies(1, "GoodBlox: We're Good", "GoodBlox is a 2007 revival aiming to replicate ROBLOX as it was in 2007!", $GLOBALS['baseURL'].'resources/images/logo.png'));
print($GLOBALS['site']->getHeader(true)); //true - show nav, false - dont show nav
//FORUMS!!
$forum = new forum();
//topics
$id = intval($_GET['id']) ?? 0;
//had to use this part from goblox because I was lazy :)
$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$keyword = isset($_GET['keyword']) ? trim($_GET['keyword']) : '';
$perPage = 20;
$offset = ($page - 1) * $perPage;
$cat = $forum->getForumCat($id);
//no.
if(!$cat){
  header('Location: /err');
  die();
}
$group = $forum->getForumGroup($cat['cat_title']);
//added some checks
if(!$group ){
  header('Location: /err');
  die();
}
//basic
$topics = $forum->getForumTopics($id, $perPage, $offset, $keyword);
$totalTopics = $forum->getForumTotalTopics($id, $keyword);
$totalPages = ceil($totalTopics / $perPage);
//you can optimize this later
?>
<link rel="stylesheet" type="text/css" href="../resources/forum.css">
<div id="Body">
              <table width="100%" cellspacing="0" cellpadding="0" border="0">
          <tbody>
            <tr>
              <td>
              </td>
            </tr>
            <tr valign="bottom">
              <td>
                <table width="100%" height="100%" cellspacing="0" cellpadding="0" border="0">
                  <tbody>
                    <tr valign="top">
                      <!-- left column -->
                      <td>&nbsp; &nbsp; &nbsp;</td>
                      <!-- center column -->
                      <td class="CenterColumn" width="95%">
                        <br>
                        <span>
                          <table width="100%" cellspacing="1" cellpadding="0">
                            <tbody>
                              <tr>
                                <td valign="middle" align="right">
                                  <a class="menuTextLink" href="/forum"><img src="/resources/icon_mini_home.gif" border="0">Home &nbsp;</a>
                                </td>
                              </tr>
                            </tbody>
                          </table>
                        </span>
                        <span>
                          <table width="100%" cellpadding="0">
                            <tbody>
                              <tr>
                                <td colspan="2" align="left">
                                  <span name="Whereami1">
                                    <table width="100%" cellspacing="0" cellpadding="0">
                                      <tbody>
                                        <tr>
                                          <td width="1px" valign="top" align="left">
                                            <nobr>

                                            </nobr>
                                          </td>
                                          <td class="popupMenuSink" width="1px" valign="top" align="left">
                                            <nobr>

                                            <a class="linkMenuSink" href="/forum/">GoodBlox Forum</a>
                                            </nobr>
                                          </td>

                                          <td class="popupMenuSink" width="1px" valign="top" align="left">
                                            <nobr>
                                              <span class="normalTextSmallBold">&nbsp;&gt;</span>
                                              <a class="linkMenuSink" href="/forum/sfg?id=<?php echo intval($group['id']); ?>"><?php echo $GLOBALS['site']->cleanOutput($group['name']); ?></a>
                                            </nobr>
                                          </td>

                                          <td class="popupMenuSink" width="1px" valign="top" align="left">
                                            <nobr>
                                              <span class="normalTextSmallBold">&nbsp;&gt;</span>
                                              <a class="linkMenuSink" href="/forum/sf?id=<?php echo intval($cat['id']); ?>"><?php echo $GLOBALS['site']->cleanOutput($cat['name']); ?></a>
                                            </nobr>
                                          </td>

                                          <td width="*" valign="top" align="left">&nbsp;</td>
                                        </tr>
                                      </tbody>
                                    </table>

                                    <span></span>
                                  </span>
                                </td>
                              </tr>
                            <tr>
                            <td>
                            &nbsp;
                            </td>
                            </tr>
                            <tr>
                              <td valign="bottom" align="left"><a href="/forum/apost?fo=1"><img src="/resources/newtopic.gif" border="0"></a></td>
                              <td align="right"><span class="normalTextSmallBold">Search this forum: </span>
                              <input id="searchKeywordForum" type="text">
                              <button onclick="window.location.href='?id=1&amp;keyword='+document.getElementById('searchKeywordForum').value" type="submit"> Go </button></td>
                            </tr>
                            <tr>
                            <td colspan="2" valign="top">
                            <table class="tableBorder" width="100%" cellspacing="1" cellpadding="3" border="0">
                              <tbody>
                                <tr>
                                  <th class="tableHeaderText" colspan="2" height="25" align="left">&nbsp;Thread&nbsp;</th>
                                  <th class="tableHeaderText" nowrap="nowrap" align="center">&nbsp;Started By&nbsp;</th>
                                  <th class="tableHeaderText" align="center">&nbsp;Replies&nbsp;</th>
                                  <th class="tableHeaderText" align="center">&nbsp;Views&nbsp;</th>
                                  <th class="tableHeaderText" nowrap="nowrap" align="center">&nbsp;Last Post&nbsp;</th>
                                </tr>
                                                                
                                                                  <?php foreach ($topics as $topic) { ?>
                                                                  <?php 
                                                                  $poster = $forum->getForumUser($topic['poster']);
                                                                  $post = $forum->getForumTopicLastPost($topic['id']);
                                                                  $replies = $forum->getForumTopicReplies($topic['id']); 
                                                                  ?>
                                <tr>
                                  <td class="forumRow" width="25" valign="middle" align="center">
                                                                          <img title="<?php if($topic['pinned']){ ?>Pinned post<?php }else{ ?>Unread Post<?php } ?>" src="<?php if($topic['pinned']){ ?>/resources/topic-pinned_notread.gif<?php }else{ ?>/resources/topic_notread.gif<?php } ?>" border="0">
                                                                      </td>
                                  <td class="forumRow" height="25">
                                    <a class="linkSmallBold" href="/forum/post?id=<?php echo intval($topic['id']); ?>"><?php echo $GLOBALS['site']->cleanOutput($topic['title']); ?></a>
                                  </td>
                                  <td class="forumRowHighlight" width="100" align="left">
                                    &nbsp;
                                    <a class="linkSmall" href="/users/?id=<?php echo intval($poster['id']); ?>"><?php echo $GLOBALS['site']->cleanOutput($poster['username']); ?></a>
                                  </td>
                                  <td class="forumRowHighlight" width="50" align="center">
                                    <span class="normalTextSmaller"><?php echo intval($replies) ?></span>
                                  </td>
                                  <td class="forumRowHighlight" width="50" align="center">
                                    <span class="normalTextSmaller"><?php echo intval($topic['views']) ?></span>
                                  </td>
                                                                      <td class="forumRowHighlight" width="140" nowrap="nowrap" align="center">
                                     <?php
                                     if($post){
                                       $poster = $forum->getForumUser($post['poster']);
                                      ?>                       
                                      <span class="normalTextSmaller">
                                      <b><?php echo date('d M Y @ h:i A', $post['post_date']); ?></b><br>by
                                      </span>
                                      <a class="linkSmall" href="/users/?id=<?php echo intval($poster['id']); ?>"><?php echo $GLOBALS['site']->cleanOutput($poster['username']); ?></a>
                                      <a href="/forum/post?id=<?php echo intval($topic['id']) ?>">
                                        <img src="/resources/icon_mini_topic.gif" border="0">
                                      </a>
                                                                        <?php } ?>
                                    </td>
                                                                  </tr>
                                <?php } ?>
                                                               
                                                              </tbody>
                            </table>
                            <span>
                              <table width="100%" cellspacing="0" cellpadding="0" border="0">
                                <tbody>
                                  <tr>
                                    <td>
                                      <span class="normalTextSmallBold">Page <?php echo intval($page); ?> of <?php echo intval($totalPages); ?></span>
                                    </td>
                                    <td align="right">
                                    <span>
                                   <?php if ($page > 1){ ?>
                                      <a class="normalTextSmallBold" href="/forum/sf?id=<?php echo $id; ?>&page=<?php echo $page - 1; ?>&keyword=<?php echo urlencode($keyword); ?>">Previous</a>
                                      &nbsp;
                                   <?php } ?>
                                   <?php if ($page < $totalPages){ ?>
                                      <a class="normalTextSmallBold" href="/forum/sf?id=<?php echo $id; ?>&page=<?php echo $page + 1; ?>&keyword=<?php echo urlencode($keyword); ?>">Next</a>
                                    <?php } ?>                                    </span>
                                    </td>
                                  </tr>
                                </tbody>
                              </table>
                            </span>
                            </td>
                            </tr>
                            <tr>
                            <td colspan="2">
                            &nbsp;
                            </td>
                            </tr>
                            <tr>
                            <td valign="top" align="left">
                            <span name="Whereami2">
                            <table width="100%" cellspacing="0" cellpadding="0">
                            <tbody><tr>
                            <td width="1px" valign="top" align="left">
                            <nobr>
                            <a class="linkMenuSink" href="/forum">GoodBlox Forum</a>
                            </nobr>
                            </td>
                            <td class="popupMenuSink" width="1px" valign="top" align="left">
                            <nobr>
                            <span class="normalTextSmallBold">&nbsp;&gt;</span>
                            <a class="linkMenuSink" href="/forum/sfg.php?id=<?php echo intval($group['id']); ?>"><?php echo $GLOBALS['site']->cleanOutput($group['name']); ?></a>
                            </nobr>
                            </td>

                            <td class="popupMenuSink" width="1px" valign="top" align="left">
                            <nobr>
                            <span class="normalTextSmallBold">&nbsp;&gt;</span>
                            <a class="linkMenuSink" href="/forum/sf.php?id=<?php echo intval($cat['id']); ?>"><?php echo $GLOBALS['site']->cleanOutput($cat['name']); ?></a>
                            </nobr>
                            </td>

                            <td class="popupMenuSink" width="1px" valign="top" align="left">
                            <nobr>


                            </nobr>
                            </td>

                            <td width="*" valign="top" align="left">&nbsp;</td>
                            </tr>
                            </tbody></table>

                            <span></span></span>

                            </td>
                            <td align="right">
                            <!--<span class="normalTextSmallBold">Display threads for: </span><select name="ctl00$cphRoblox$ThreadView1$ctl00$DisplayByDays">
                            <option selected="selected" value="0">All Days</option>
                            <option value="1">Today</option>
                            <option value="3">Past 3 Days</option>
                            <option value="7">Past Week</option>
                            <option value="14">Past 2 Weeks</option>
                            <option value="30">Past Month</option>
                            <option value="90">Past 3 Months</option>
                            <option value="180">Past 6 Months</option>
                            <option value="360">Past Year</option>

                            </select>
                            <br>
                            <a class="linkSmallBold" href="javascript:__doPostBack('ctl00$cphRoblox$ThreadView1$ctl00$MarkAllRead','')">Mark all threads as read</a>
                            <br>
                            <span class="normalTextSmallBold">

                            </span>-->
                            </td>
                            </tr>
                            <tr>
                            <td colspan="2">&nbsp;
                            </td>
                            </tr>
                            </tbody>
                          </table>
                        </span>
                      </td>

                      <td class="CenterColumn">&nbsp;&nbsp;&nbsp;</td>
                      <!-- right margin -->
                      <td class="RightColumn">&nbsp;&nbsp;&nbsp;</td>

                    </tr>
                  </tbody>
                </table>
              </td>
            </tr>
          </tbody>
        </table>
            </div>
<?php print($GLOBALS['site']->getFooter()); ?>