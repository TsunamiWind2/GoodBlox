<?php
require '../goodblox/core/config.php';
//fo34ums
require '../goodblox/classes/forum.php';
$GLOBALS['site'] = new site();
print($GLOBALS['site']->getDependencies(1, "GoodBlox: We're Good", "GoodBlox is a 2007 revival aiming to replicate ROBLOX as it was in 2007!", $GLOBALS['baseURL'].'resources/images/logo.png'));
print($GLOBALS['site']->getHeader(true)); //true - show nav, false - dont show nav
//FORUMS!!
$forum = new forum();
//groups
$GOODBLOX = $forum->getForumGroup(1);
$G_1 = $forum->getForumCats($GOODBLOX['id']);
$HELP_CENTER = $forum->getForumGroup(2);
$G_2 = $forum->getForumCats($HELP_CENTER['id']);
$FUN = $forum->getForumGroup(3);
$G_3 = $forum->getForumCats($FUN['id']);
$ENTERTAINMENT= $forum->getForumGroup(4);
$G_4 = $forum->getForumCats($ENTERTAINMENT['id']);
?>
<link rel="stylesheet" type="text/css" href="../resources/forum.css">
<div id="Body">
            <table width="100%" cellspacing="0" cellpadding="0" border="0">
               <tbody>
                  <tr>
                     <td>
                     </td>
                  </tr>
                  <tr valign="bottom">
                     <td>
                        <table width="100%" height="100%" cellspacing="0" cellpadding="0" border="0">
                           <tbody>
                              <tr valign="top">
                                 <!-- left column -->
                                 <td class="LeftColumn">&nbsp;&nbsp;&nbsp;</td>
                                 <td class="LeftColumn">&nbsp;&nbsp;&nbsp;</td>
                                 <!-- center column -->
                                 <td class="CenterColumn">&nbsp;&nbsp;&nbsp;</td>
                                 <td class="CenterColumn" width="95%">
                                    <span>
                                       <table width="100%" cellspacing="1" cellpadding="0">
                                          <tbody>
                                             <tr>
                                                <td valign="middle" align="right">
                                                   <a class="menuTextLink" href=""><img src="../resources/icon_mini_home.gif" border="0">Home &nbsp;</a>
                                                </td>
                                             </tr>
                                          </tbody>
                                       </table>
                                    </span>
                                    <br>
                                    <table width="100%" cellspacing="2" cellpadding="0">
                                       <tbody>
                                          <tr>
                                             <td align="left">
                                                <span class="normalTextSmallBold">Current time: </span><span class="normalTextSmall"><?php echo date('M d, h:i A'); ?></span>
                                             </td>
                                             <td align="right">
                                             </td>
                                          </tr>
                                       </tbody>
                                    </table>
                                    <table class="tableBorder" width="100%" cellspacing="1" cellpadding="2" border="0">
                                       <tbody>
                                          <tr>
                                             <th class="tableHeaderText" colspan="2" height="20">Forum</th>
                                             <th class="tableHeaderText" width="50" nowrap="nowrap">&nbsp;&nbsp;Threads&nbsp;&nbsp;</th>
                                             <th class="tableHeaderText" width="50" nowrap="nowrap">&nbsp;&nbsp;Posts&nbsp;&nbsp;</th>
                                             <th class="tableHeaderText" width="135" nowrap="nowrap">&nbsp;Last Post&nbsp;</th>
                                          </tr>
                                          <tr>
                                             <td class="forumHeaderBackgroundAlternate" colspan="5" height="20">
                                                <a class="forumTitle" href="sfg?id=1">GoodBlox</a>
                                             </td>
                                          </tr>
                                          <tr>
                                            <?php foreach ($G_1 as $cat) { ?>
                                            <?php
                                            $post_1 = $forum->getForumLastPost($cat['id']);
                                            ?>
                                             <td class="forumRow" width="34" valign="top" nowrap="nowrap" align="center">
                                                <img src="../resources/forum_status.gif" width="34" border="0">
                                             </td>
                                             <td class="forumRow" width="80%">
                                                <a class="forumTitle" href="sf?id=<?php echo $GLOBALS['site']->cleanOutput($cat['id']); ?>"><?php echo $GLOBALS['site']->cleanOutput($cat['name']); ?></a>
                                                <span class="normalTextSmall"><br>
                                                      <?php echo $GLOBALS['site']->cleanOutput($cat['description']); ?>
                                                </span>
                                             </td>
                                             <td class="forumRowHighlight" align="center">
                                                <span class="normalTextSmaller"><?php echo intval($forum->getForumTotalTopics($cat['id'])); ?></span>
                                             </td>
                                             <td class="forumRowHighlight" align="center">
                                                <span class="normalTextSmaller"><?php echo intval($forum->getForumTotalReplies($cat['id'])); ?></span> 
                                             </td>

                                             
                                             <td class="forumRowHighlight" width="140" nowrap="nowrap" align="center">
                                                <?php 
                                                if($post_1){
                                                  $poster_1 = $forum->getForumUser($post_1['poster']); 
                                                ?>
                                                <span class="normalTextSmaller">
                                                                                                            <b><?php echo date('d M Y @ h:i A', $post_1['post_date']); ?></b><br>by
                                                         <a class="linkSmall" href="/users?id=<?php echo $GLOBALS['site']->cleanOutput($poster_1['id']); ?>">
                                                            <?php echo $GLOBALS['site']->cleanOutput($poster_1['username']); ?></a>
                                                         <a href="post?id=<?php echo $GLOBALS['site']->cleanOutput($post_1['id']); ?>">
                                                            <img src="../resources/icon_mini_topic.gif" border="0">
                                                         </a>
                                                                                                   </span>
                                               <?php } ?>
                                             </td>
                                          </tr>
                                         <?php } ?>
                                          <tr>
                                             <td class="forumHeaderBackgroundAlternate" colspan="5" height="20">
                                                <a class="forumTitle" href="sfg?id=2">Help Center</a>
                                             </td>
                                          </tr>
                                          <tr>
                                        <?php foreach ($G_2 as $cat) { ?>
                                            <?php
                                            $post_2 = $forum->getForumLastPost($cat['id']);
                                            ?>
                                             <td class="forumRow" width="34" valign="top" nowrap="nowrap" align="center">
                                                <img src="../resources/forum_status.gif" width="34" border="0">
                                             </td>
                                             <td class="forumRow" width="80%">
                                                <a class="forumTitle" href="sf?id=<?php echo $GLOBALS['site']->cleanOutput($cat['id']); ?>"><?php echo $GLOBALS['site']->cleanOutput($cat['name']); ?></a>
                                                <span class="normalTextSmall"><br>
                                                      <?php echo $GLOBALS['site']->cleanOutput($cat['description']); ?>
                                                </span>
                                             </td>
                                             <td class="forumRowHighlight" align="center">
                                                <span class="normalTextSmaller"><?php echo intval($forum->getForumTotalTopics($cat['id'])); ?></span>
                                             </td>
                                             <td class="forumRowHighlight" align="center">
                                                <span class="normalTextSmaller"><?php echo intval($forum->getForumTotalReplies($cat['id'])); ?></span>
                                             </td>

                                             
                                             <td class="forumRowHighlight" width="140" nowrap="nowrap" align="center">
                                                <?php
                                                if($post_2){
                                                  $poster_2 = $forum->getForumUser($post_2['poster']); 
                                                ?>
                                                <span class="normalTextSmaller">
                                                                                                            <b><?php echo date('d M Y @ h:i A', $post_2['post_date']); ?></b><br>by
                                                         <a class="linkSmall" href="/users?id=<?php echo $GLOBALS['site']->cleanOutput($poster_2['id']); ?>">
                                                            <?php echo $GLOBALS['site']->cleanOutput($poster_2['username']); ?></a>
                                                         <a href="post?id=<?php echo $GLOBALS['site']->cleanOutput($post_2['id']); ?>">
                                                            <img src="../resources/icon_mini_topic.gif" border="0">
                                                         </a>
                                                                                                   </span>
                                               <?php } ?>
                                             </td>
                                          </tr>
                                         <?php } ?>
                                          <tr>
                                             <td class="forumHeaderBackgroundAlternate" colspan="5" height="20">
                                                <a class="forumTitle" href="sfg?id=3">Fun</a>
                                             </td>
                                          </tr>
                                          <tr>
                                            <?php foreach ($G_3 as $cat) { ?>
                                            <?php
                                            $post_3 = $forum->getForumLastPost($cat['id']);
                                            ?>
                                             <td class="forumRow" width="34" valign="top" nowrap="nowrap" align="center">
                                                <img src="../resources/forum_status.gif" width="34" border="0">
                                             </td>
                                             <td class="forumRow" width="80%">
                                                <a class="forumTitle" href="sf?id=<?php echo $GLOBALS['site']->cleanOutput($cat['id']); ?>"><?php echo $GLOBALS['site']->cleanOutput($cat['name']); ?></a>
                                                <span class="normalTextSmall"><br>
                                                      <?php echo $GLOBALS['site']->cleanOutput($cat['description']); ?>
                                                </span>
                                             </td>
                                             <td class="forumRowHighlight" align="center">
                                                <span class="normalTextSmaller"><?php echo intval($forum->getForumTotalTopics($cat['id'])); ?></span>
                                             </td>
                                             <td class="forumRowHighlight" align="center">
                                                <span class="normalTextSmaller"><?php echo intval($forum->getForumTotalReplies($cat['id'])); ?></span>
                                             </td>

                                             
                                             <td class="forumRowHighlight" width="140" nowrap="nowrap" align="center">
                                                <?php
                                                if($post_3){
                                                  $poster_3 = $forum->getForumUser($post_3['poster']);
                                                ?>
                                                <span class="normalTextSmaller">
                                                                                                            <b><?php echo date('d M Y @ h:i A', $post_3['post_date']); ?></b><br>by
                                                         <a class="linkSmall" href="/users?id=<?php echo $GLOBALS['site']->cleanOutput($poster_3['id']); ?>">
                                                            <?php echo $GLOBALS['site']->cleanOutput($poster_3['username']); ?></a>
                                                         <a href="post?id=<?php echo $GLOBALS['site']->cleanOutput($post_3['id']); ?>">
                                                            <img src="../resources/icon_mini_topic.gif" border="0">
                                                         </a>
                                                                                                   </span>
                                               <?php } ?>
                                             </td>
                                          </tr>
                                         <?php } ?>
                                          <tr>
                                             <td class="forumHeaderBackgroundAlternate" colspan="5" height="20">
                                                <a class="forumTitle" href="sfg?id=4">Entertainment</a>
                                             </td>
                                          </tr>
                                          <tr>
                                           <?php foreach ($G_4 as $cat) { ?>
                                            <?php
                                            $post_4 = $forum->getForumLastPost($cat['id']);
                                            ?>
                                             <td class="forumRow" width="34" valign="top" nowrap="nowrap" align="center">
                                                <img src="../resources/forum_status.gif" width="34" border="0">
                                             </td>
                                             <td class="forumRow" width="80%">
                                                <a class="forumTitle" href="sf?id=<?php echo $GLOBALS['site']->cleanOutput($cat['id']); ?>"><?php echo $GLOBALS['site']->cleanOutput($cat['name']); ?></a>
                                                <span class="normalTextSmall"><br>
                                                      <?php echo $GLOBALS['site']->cleanOutput($cat['description']); ?>
                                                </span>
                                             </td>
                                             <td class="forumRowHighlight" align="center">
                                                <span class="normalTextSmaller"><?php echo intval($forum->getForumTotalTopics($cat['id'])); ?></span>
                                             </td>
                                             <td class="forumRowHighlight" align="center">
                                                <span class="normalTextSmaller"><?php echo intval($forum->getForumTotalReplies($cat['id'])); ?></span>
                                             </td>

                                             
                                             <td class="forumRowHighlight" width="140" nowrap="nowrap" align="center">
                                                <?php
                                                if($post_4){
                                                  $poster_4 = $forum->getForumUser($post_4['poster']);
                                                ?>
                                                <span class="normalTextSmaller">
                                                                                                            <b><?php echo date('d M Y @ h:i A', $post_4['post_date']); ?></b><br>by
                                                         <a class="linkSmall" href="/users?id=<?php echo $GLOBALS['site']->cleanOutput($poster_4['id']); ?>">
                                                            <?php echo $GLOBALS['site']->cleanOutput($poster_4['username']); ?></a>
                                                         <a href="post?id=<?php echo $GLOBALS['site']->cleanOutput($post_4['id']); ?>">
                                                            <img src="../resources/icon_mini_topic.gif" border="0">
                                                         </a>
                                                                                                   </span>
                                               <?php } ?>
                                             </td>
                                          </tr>
                                         <?php } ?>
                                          </tr>
                                       </tbody>
                                    </table>
                                    <p></p>
                                 </td>
                                 <td class="CenterColumn">&nbsp;&nbsp;&nbsp;</td>
                                 <!-- right margin -->
                                 <td class="RightColumn">&nbsp;&nbsp;&nbsp;</td>
                              </tr>
                           </tbody>
                        </table>
                     </td>
                  </tr>
               </tbody>
            </table>
         </div>
<?php print($GLOBALS['site']->getFooter()); ?>