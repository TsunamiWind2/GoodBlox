<?php
require '../goodblox/core/config.php';
//friends
require '../goodblox/classes/friends.php';
$GLOBALS['site'] = new site();
print($GLOBALS['site']->getDependencies(1, "GoodBlox: We're Good", "GoodBlox is a 2007 revival aiming to replicate ROBLOX as it was in 2007!", $GLOBALS['baseURL'].'resources/images/logo.png'));
print($GLOBALS['site']->getHeader(true)); //true - show nav, false - dont show nav
//FRIENDS PAGEEEE
$of = intval($_GET['of']) ?? 0; //id
//paging
$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$friends = new friends($of);
$usert = $friends->usert($of);
//hi jack,
if(!$usert){
  header('Location: /err');
  die();
}
$FRIENDS = $friends->getFriendsV2($page, 30);
//total friends
$total = $friends->getFriendsTotal();
$perPage = 30;
$totalPages = ceil($total / $perPage);
$yes = 0;
?>
<div id="Body">
            <div id="FriendsContainer">
                <div id="Friends">
                    <h4><?php echo $GLOBALS['site']->cleanOutput($usert['username']); ?>'s Friends (<?php echo intval($total); ?>)</h4>
                    <div align="center">
                  <?php if($page > 1): ?>
                     <a href="?of=<?php echo $of; ?>&page=<?php echo $page - 1; ?>">« Previous</a>
                  <?php endif; ?>
                    Pages:
                  <?php if($page < $totalPages): ?>
                     <a href="?of=<?php echo $of; ?>&page=<?php echo $page + 1; ?>">Next »</a>
                  <?php endif; ?>                                       
                </div>
                
                    <table cellspacing="0" border="0" align="Center">
                    <tbody>
                                        <?php 
                                            foreach ($FRIENDS as $i => $FRIEND){
                                               $FRIEND_I = $friends->getFriend($FRIEND['uid'], $FRIEND['fid'], $of);
                                               if ($yes % 5 == 0){
                                                 echo "<tr>";
                                               } 
                                            ?>
                                                            <td>
            <div class="Friend">
              <div class="Avatar">
                <a title="<?php echo $GLOBALS['site']->cleanOutput($FRIEND_I->username); ?>" href="/users?id=<?php echo intval($FRIEND_I->id); ?>" style="display:inline-block;height:100px;width:100px;cursor:pointer;">
                  <img src="/goodblox/images/render/avatar/<?php echo intval($FRIEND_I->id); ?>-small.png" onerror="this.onerror=null; this.src='<?php echo $GLOBALS['baseURL']; ?>/goodblox/images/render/avatar/default-small.png';" border="0" id="img" alt="<?php echo $GLOBALS['site']->cleanOutput($FRIEND_I->username); ?>">
                </a>
              </div>
              <div class="Summary">
                              <span class="OnlineStatus"><img src="/resources/OnlineStatusIndicator_<?php echo $FRIEND_I->lastseen + 300 <= time() ? 'IsOffline' : 'IsOnline'; ?>.gif" alt="<?php if($FRIEND_I->lastseen + 300 <= time()){ ?><?php echo $GLOBALS['site']->cleanOutput($FRIEND_I->username); ?> is offline (last seen at <?php echo date('n/j/Y g:i:s A', $FRIEND_I->lastseen); ?>).<?php } else { ?><?php echo $GLOBALS['site']->cleanOutput($FRIEND_I->username); ?> is online at Web Site.<?php } ?>" style="border-width:0px;"></span>
                              <span class="Name"><a href="/users?id=<?php echo intval($FRIEND_I->id); ?>"><?php echo $GLOBALS['site']->cleanOutput($FRIEND_I->username); ?></a></span>
              </div>
            </div>
                    </td><?php $yes++; } if(empty($FRIENDS)){ echo ''; } ?>
                                         <?php 
                                         if ($yes % 5 == 0){
                                            echo "<tr>";
                                         } 
                                         ?>
                </tbody></table>
                </div>
            </div>
        </div>
<?php print($GLOBALS['site']->getFooter()); ?>