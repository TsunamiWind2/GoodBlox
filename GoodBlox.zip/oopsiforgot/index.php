<?php
require '../goodblox/core/config.php';
$GLOBALS['site'] = new site();
print($GLOBALS['site']->getDependencies(1, "GoodBlox: We're Good", "GoodBlox is a 2007 revival aiming to replicate ROBLOX as it was in 2007!", $GLOBALS['baseURL'].'resources/'));
print($GLOBALS['site']->getHeader(false)); //true - show nav, false - dont show nav
//todo: add email stuff
?>
<div id="Body">
                    <form method="post">
                                        <h3>
                        Forgot your password?</h3>
                    <p>
                        We can send you an email to reset it.<br>
                    </p>
                    <p>
                        Username:
                        <input name="un" type="text" id="UserName"></p>&nbsp;<input id="ResetPassword" name="rpw" type="submit" value="Reset password" class="Button">
                        <br>
                        <br>
                              </form>
        </div>
<?php print($GLOBALS['site']->getFooter()); ?>