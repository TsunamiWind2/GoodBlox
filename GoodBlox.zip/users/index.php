<?php
require '../goodblox/core/config.php';
//load users09$546 class/
require '../goodblox/classes/users.php';
require '../goodblox/classes/home.php'; //home class
//friends
require '../goodblox/classes/friends.php';
$GLOBALS['site'] = new site();
print($GLOBALS['site']->getDependencies(1, "GoodBlox: We're Good", "GoodBlox is a 2007 revival aiming to replicate ROBLOX as it was in 2007!", $GLOBALS['baseURL'].'resources/images/logo.png'));
print($GLOBALS['site']->getHeader(true)); //true - show nav, false - dont show nav
//USER PAGE
if(isset($_GET['id'])) {
$id = intval($_GET['id']) ?? 0; //ids
$GLOBALS['home'] = new home(); // my/home page
//doing array for some reason
$GLOBALS['profile'] = $GLOBALS['home']->bro($id);
$GLOBALS['friends'] = new friends($GLOBALS['profile']['id']);
//inventory syst%$%m
if(isset($_GET['itemtype'])){
  $type = $_GET['itemtype'];
  if($type == 1){
    $assets = $GLOBALS['home']->inv($GLOBALS['profile']['id'], 1);
    $stat_1 = true;
    $stat_2 = false;
  }elseif($type == 2){
    $assets = $GLOBALS['home']->inv($GLOBALS['profile']['id'], 2);
    $stat_1 = false;
    $stat_2 = true;
  }else{
    die();
    //bro thought he could slide
    //lol
  }
}else{
  $assets = $GLOBALS['home']->inv($GLOBALS['profile']['id'], 1);
  $stat_1 = true;
  $stat_2 = false;
}
//STATISTICS YEHOO
$stmt = $pdo->prepare("SELECT COUNT(*) FROM profile_views WHERE profile_id = :uid");
$stmt->execute(['uid' => $GLOBALS['profile']['id']]);
$STATISTICS['profile_views']['total'] = (int)$stmt->fetchColumn();
//yes profile views last week, peak
$stmt = $pdo->prepare("SELECT COUNT(*) FROM profile_views WHERE profile_id = :uid AND when_viewed >= UNIX_TIMESTAMP(DATE_SUB(NOW(), INTERVAL 7 DAY))");
$stmt->execute(['uid' => $GLOBALS['profile']['id']]);
$STATISTICS['profile_views']['last_week'] = (int)$stmt->fetchColumn();
//get friends
$FRIENDS = $GLOBALS['friends']->getFriends();
$TOTAL_FRIENDS = $GLOBALS['friends']->getFriendsTotal();
//get friend requests
$FRIEND_REQUESTS = $GLOBALS['friends']->getFriendRequests($GLOBALS['profile']['id']);
$TOTAL_FRIEND_REQUESTS = $GLOBALS['friends']->getFriendRequestsTotal($GLOBALS['profile']['id']);
//banned bozo
$GLOBALS['banned'] = $GLOBALS['banHandler']->banned(intval($GLOBALS['profile']['id'])); //trust
if($GLOBALS['banned']) {
  header('Location: /err');
  die();
}
?>
<div id="Body">
          
  
  <div id="UserContainer">
    <div id="LeftBank">
      <div id="ctl00_cphRoblox_pProfile">
  
        <div id="ProfilePane">
          
<table width="100%" bgcolor="lightsteelblue" cellpadding="6" cellspacing="0">
    <tbody><tr>
        <td>
            <span id="ctl00_cphRoblox_rbxUserPane_lUserName" class="Title"><?php echo $GLOBALS['site']->cleanOutput($GLOBALS['profile']['username']); ?></span><br>
            <span class="User<?php echo $GLOBALS['profile']['lastseen'] + 300 <= time() ? 'Offline' : 'Online'; ?>Message">[ <?php echo $GLOBALS['profile']['lastseen'] + 300 <= time() ? 'Offline' : 'Online: Web Site'; ?> ]</span>
        </td>
    </tr>
    <tr>
        <td>
            <span id="ctl00_cphRoblox_rbxUserPane_lUserRobloxURL"><?php echo $GLOBALS['site']->cleanOutput($GLOBALS['profile']['username']); ?>'s GoodBlox:</span><br>
            <a id="ctl00_cphRoblox_rbxUserPane_hlUserRobloxURL" href="/users?id=<?php echo intval($GLOBALS['profile']['id']); ?>">https://<?php echo $_SERVER['HTTP_HOST']; ?>/users?id=<?php echo intval($GLOBALS['profile']['id']); ?></a><br>
            <br>
          
            <div style="left: 0px; float: left; position: relative; top: 0px">
                <a id="ctl00_cphRoblox_rbxUserPane_Image1" disabled="disabled" title="<?php echo $GLOBALS['site']->cleanOutput($GLOBALS['profile']['username']); ?>" onclick="return false" style="display:inline-block;height:220px;width:180px;"><img src="/goodblox/images/render/avatar/<?php echo intval($GLOBALS['profile']['id']); ?>.png" onerror="this.onerror=null; this.src='<?php echo $GLOBALS['baseURL']; ?>/goodblox/images/render/avatar/default.png';" border="0" id="img" alt="<?php echo $GLOBALS['site']->cleanOutput($GLOBALS['profile']['username']); ?>"></a><br>
                <div class="ReportAbusePanel">
    
                <a href="/report/profile?id=1"><span class="AbuseIcon"><img src="/resources/abuse.gif" alt="Report Abuse" border="0"></span>
                <span class="AbuseButton">Report Abuse</span></a>

                </div>
            </div>

<p><span><?php echo nl2br($GLOBALS['site']->cleanOutput($GLOBALS['profile']['blurb']));  ?></span></p>
            
        </td>
    </tr>
</tbody></table>

        </div>
      
</div>
      <div id="ctl00_cphRoblox_pUserBadges">
  
        <div id="UserBadgesPane">
          

<div id="UserBadges">
  <h4><a id="ctl00_cphRoblox_rbxUserBadgesPane_hlHeader" href="/badges">Badges</a></h4>
  <table id="ctl00_cphRoblox_rbxUserBadgesPane_dlBadges" cellspacing="0" align="Center" border="0" style="border-collapse:collapse;">
    <tbody><tr>
      <?php   
      //rows = 0
      $rows = 0;
      $stmt = $pdo->prepare("SELECT * FROM owned_badges WHERE uid = :uid");
      $stmt->execute(['uid' => $GLOBALS['profile']['id']]);
      $owned_badges = $stmt->fetchAll(PDO::FETCH_ASSOC);
      //really cool badge system with rows
      if (count($owned_badges) > 0) { 
         echo "<tr>";
      } else {
         echo '<div id="ctl00_cphRoblox_rbxUserBadgesPane_pNoResults">
                <p class="NoResults"><span id="ctl00_cphRoblox_rbxUserBadgesPane_lNoResults">'.$GLOBALS['site']->cleanOutput($GLOBALS['profile']['username']).' does not yet have any GOODBLOX badges.</span></p>
               </div>';
      }
      //best badge fetch system
      foreach ($owned_badges as $badge) {
         $rows++;
         $stmt = $GLOBALS['pdo']->prepare("SELECT * FROM badges WHERE id = :bid");
         $stmt->execute(['bid' => $badge['bid']]);
         $badge = $stmt->fetch(PDO::FETCH_ASSOC);
         if ($rows == 5) {
            $rows = 1;
            echo "</tr><tr>";
         }
      ?>
     <td>
      <div class="Badge">
        <div class="BadgeImage"><a id="ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl02_hlHeader" href="/badges"><img id="ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl02_iBadge" src="<?php echo $badge['img_location']; ?>" alt="<?php echo $GLOBALS['site']->cleanOutput($badge['description']); ?>" style="height:75px;border-width:0px;"></a></div>
        <div class="BadgeLabel"><a id="ctl00_cphRoblox_rbxUserBadgesPane_dlBadges_ctl02_HyperLink1" href="/badges"><?php echo $GLOBALS['site']->cleanOutput($badge['name']); ?></a></div>
      </div>
    </td><?php } ?>
      <?php
      //after 5 rows close <tr> with empty cells of tds
      if ($rows % 5 !== 0) {
        $remaining = 5 - ($rows % 5);
        for ($i = 0; $i < $rows; $i++) {
            echo '<td></td>';
        }
        echo '</tr>';
      }
      ?>
  </tbody></table>
  
</div>
        </div>
      
</div>
<div id="ctl00_cphRoblox_pUserStatistics">
  
        <div id="UserStatisticsPane">
          

<div id="UserStatistics">
  <div id="ctl00_cphRoblox_rbxUserStatisticsPane_upBody" style="height: 200px;">
    
      <input name="ctl00$cphRoblox$rbxUserStatisticsPane$cpeUserStatistics_ClientState" id="ctl00_cphRoblox_rbxUserStatisticsPane_cpeUserStatistics_ClientState" value="false" type="hidden">
      <div id="ctl00_cphRoblox_rbxUserStatisticsPane_pHeader">
      
        <div class="Header">
          <h4>Statistics</h4>
          <span class="PanelToggle">
            <input name="ctl00$cphRoblox$rbxUserStatisticsPane$ibCue" id="ctl00_cphRoblox_rbxUserStatisticsPane_ibCue" src="/resources/ExpandButton.jpg" style="border-width:0px;" type="image">
          </span>
        </div>        
      
    </div>
      
      <div id="ctl00_cphRoblox_rbxUserStatisticsPane_pBody" style="margin: 10px 10px 150px 10px;">
      
        
        <div id="ctl00_cphRoblox_rbxUserStatisticsPane_pResults">
        
          <div id="Results">
            <div class="Statistic">
              <div class="Label"><acronym title="The number of this user's friends.">Friends</acronym>:</div>
              <div class="Value"><span id="ctl00_cphRoblox_rbxUserStatisticsPane_lFriendsStatistics"><?php echo intval($TOTAL_FRIENDS); ?> (0 last week)</span></div>
            </div>
            <div id="ctl00_cphRoblox_rbxUserStatisticsPane_pInvitations">
          
              <div class="Statistic">
                <div class="Label"><acronym title="The number of friends this user has recruited to join ROBLOX.">Friends Invited</acronym>:</div>
                <div class="Value"><span id="ctl00_cphRoblox_rbxUserStatisticsPane_lFriendsInvitedStatistics">0 (0 last week)</span></div>
              </div>
            
        </div>
            <div class="Statistic">
              <div class="Label"><acronym title="The number of posts this user has made to the ROBLOX forum.">Forum Posts</acronym>:</div>
              <div class="Value"><span id="ctl00_cphRoblox_rbxUserStatisticsPane_lForumPostsStatistics">0 (0 last week)</span></div>
            </div>
            <div class="Statistic">
              <div class="Label"><acronym title="The number of times this user's profile has been viewed.">Profile Views</acronym>:</div>
              <div class="Value"><span id="ctl00_cphRoblox_rbxUserStatisticsPane_lProfileViewsStatistics"><?php echo intval($STATISTICS['profile_views']['total']); ?> (<?php echo intval($STATISTICS['profile_views']['last_week']); ?> last week)</span></div>
            </div>
            <div class="Statistic">
              <div class="Label"><acronym title="The number of times this user's place has been visited.">Place Visits</acronym>:</div>
              <div class="Value"><span id="ctl00_cphRoblox_rbxUserStatisticsPane_lPlaceVisitsStatistics">0 (0 last week)</span></div>
            </div>
            <div class="Statistic">
              <div class="Label"><acronym title="The number of times this user's models have been viewed.">Model Views</acronym>:</div>
              <div class="Value"><span id="ctl00_cphRoblox_rbxUserStatisticsPane_lModelViewsStatistics">0 (0 last week)</span></div>
            </div>
            <div class="Statistic">
              <div class="Label"><acronym title="The number of times this user's character has destroyed another user's character in-game.">Knockouts</acronym>:</div>
              <div class="Value"><span id="ctl00_cphRoblox_rbxUserStatisticsPane_lKillsStatistics">0 (0 last week)</span></div>
            </div>
            <div id="ctl00_cphRoblox_rbxUserStatisticsPane_pDeaths">
          
              <div class="Statistic">
                <div class="Label"><acronym title="The number of times this user's character has been destroyed in-game.">Wipeouts</acronym>:</div>
                <div class="Value"><span id="ctl00_cphRoblox_rbxUserStatisticsPane_lDeathsStatistics">0 (0 last week)</span></div>
              </div>
            
          </div>
        
      </div>
      
    </div>
    
  </div>
</div>
        </div>
      
</div>
      
</div>
    </div>
    <div id="RightBank">
      
      <div id="ctl00_cphRoblox_pFriends">
  
        <div id="FriendsPane">
          

<div id="Friends">
  <h4><?php echo $GLOBALS['site']->cleanOutput($GLOBALS['profile']['username']); ?>'s Friends <a href="/friends?of=1">See all <?php echo intval($TOTAL_FRIENDS); ?></a> </h4>
    
  <table id="ctl00_cphRoblox_rbxFriendsPane_dlFriends" cellspacing="0" align="Center" border="0" style="border-collapse:collapse;">
    <tbody><?php if (!empty($FRIENDS)) { ?>
      <tr>
      <?php
      foreach ($FRIENDS as $i => $FRIEND) {
         $FRIEND_I = $GLOBALS['friends']->getFriend($FRIEND['uid'], $FRIEND['fid'], $GLOBALS['profile']['id']);
      ?>
      <td>
      <div class="Friend">
        <div class="Avatar"><a id="ctl00_cphRoblox_rbxFriendsPane_dlFriends_ctl00_hlAvatar" title="<?php echo $GLOBALS['site']->cleanOutput($FRIEND_I->username); ?>" href="/users?id=<?php echo intval($FRIEND_I->id); ?>" style="display:inline-block;height:100px;width:100px;cursor:pointer;"><img src="/goodblox/images/render/avatar/<?php echo intval($FRIEND_I->id); ?>-small.png" onerror="this.onerror=null; this.src='<?php echo $GLOBALS['baseURL']; ?>/goodblox/images/render/avatar/default-small.png';" border="0" id="img" alt="<?php echo $GLOBALS['site']->cleanOutput($FRIEND_I->username); ?>"></a></div>
        <div class="Summary">
          <span class="OnlineStatus"><img id="ctl00_cphRoblox_rbxFriendsPane_dlFriends_ctl00_iOnlineStatus" src="/resources/OnlineStatusIndicator_<?php echo $FRIEND_I->lastseen + 300 <= time() ? 'IsOffline' : 'IsOnline'; ?>.gif" alt="<?php if($FRIEND_I->lastseen + 300 <= time()){ ?><?php echo $GLOBALS['site']->cleanOutput($FRIEND_I->username); ?> is offline (last seen at <?php echo date('n/j/Y g:i:s A', $FRIEND_I->lastseen); ?>).<?php } else { ?><?php echo $GLOBALS['site']->cleanOutput($FRIEND_I->username); ?> is online at Web Site.<?php } ?>" style="border-width:0px;"></span>
          <span class="Name"><a id="ctl00_cphRoblox_rbxFriendsPane_dlFriends_ctl00_hlFriend" href="/users?id=<?php echo intval($FRIEND_I->id); ?>"><?php echo $GLOBALS['site']->cleanOutput($FRIEND_I->username); ?></a></span>
        </div>
      </div>
    </td>
    <?php if (($i + 1) % 3 === 0) { ?>
    </tr><tr>
    <?php } ?>
    <?php } ?>
    </tr>
    <?php } else { ?>
     <div id="ctl00_cphRoblox_rbxUserBadgesPane_pNoResults">
         <p class="NoResults"><span id="ctl00_cphRoblox_rbxUserBadgesPane_lNoResults"><?php echo $GLOBALS['site']->cleanOutput($GLOBALS['profile']['username']); ?> does not yet have any GOODBLOX friends.</span></p>
     </div>
    <?php } ?>
  </tbody></table>
  
</div>
          
        </div>
     
    
    </div>
   </div>
    <div id="ctl00_cphRoblox_pUserAssets">
  
      <div id="UserAssetsPane">
        <div id="ctl00_cphRoblox_rbxUserAssetsPane_upUserAssetsPane">
    
    <div id="UserAssets">
      <h4>Stuff</h4>
      <div id="AssetsMenu">
        
            <div onclick="window.location.href='/users?id=<?php echo $GLOBALS['profile']['id']; ?>&itemtype=1'" class="AssetsMenuItem<?php if(isset($stat_1) && $stat_1){ echo '_Selected'; } ?>">
      <a id="ctl00_cphRoblox_rbxUserAssetsPane_AssetCategoryRepeater_ctl00_AssetCategorySelector" class="AssetsMenuButton<?php if(isset($stat_1) && $stat_1){ echo '_Selected'; } ?>">Hats</a>
    </div>
          
            <div onclick="window.location.href='/users?id=<?php echo $GLOBALS['profile']['id']; ?>&itemtype=2'" class="AssetsMenuItem<?php if(isset($stat_2) && $stat_2){ echo '_Selected'; } ?>">
      <a id="ctl00_cphRoblox_rbxUserAssetsPane_AssetCategoryRepeater_ctl01_AssetCategorySelector" class="AssetsMenuButton<?php if(isset($stat_2) && $stat_2){ echo '_Selected'; } ?>" >Shirts</a>
    </div>
          
      </div>
      <div id="AssetsContent">
        
        <table id="ctl00_cphRoblox_rbxUserAssetsPane_UserAssetsDataList" cellspacing="0" border="0" style="border-collapse:collapse;">
      <tbody>
        <?php if (!empty($assets)) { ?>
        <tr>
        <?php
        //hi catalog items :)
        foreach ($assets as $i => $asset) {
          $stmt = $GLOBALS['pdo']->prepare("SELECT * FROM catalog_items WHERE id = :aid");
          $stmt->execute([':aid' => $asset['aid']]);
          $item = $stmt->fetch(PDO::FETCH_ASSOC);
          //creator
          $stmt = $GLOBALS['pdo']->prepare("SELECT * FROM users WHERE id = :uid");
          $stmt->execute([':uid' => $item['creator_id']]);
          $creator = $stmt->fetch(PDO::FETCH_ASSOC);
        ?>
        <td class="Asset" valign="top">
              <div style="padding:5px">
            <div class="AssetThumbnail">
              <a id="ctl00_cphRoblox_rbxUserAssetsPane_UserAssetsDataList_ctl00_AssetThumbnailHyperLink" title="<?php echo $GLOBALS['site']->cleanOutput($item['name']); ?>" href="/catalog/item?id=<?php echo intval($item['id']); ?>" style="display:inline-block;height:110px;width:110px;cursor:pointer;"><img src="<?php echo $GLOBALS['baseURL']; ?>/goodblox/images/render/tshirt/<?php echo intval($item['id']); ?>.png" width="110px" border="0" id="img" alt="<?php echo $GLOBALS['site']->cleanOutput($item['name']); ?>"></a>
            </div>
            <div class="AssetDetails">
              <div class="AssetName"><a id="ctl00_cphRoblox_rbxUserAssetsPane_UserAssetsDataList_ctl00_AssetNameHyperLink" href="/catalog/item?id=<?php echo intval($item['id']); ?>"><?php echo $GLOBALS['site']->cleanOutput($item['name']); ?></a></div>
              <div class="AssetCreator"><span class="Label">Creator:</span> <span class="Detail"><a id="ctl00_cphRoblox_rbxUserAssetsPane_UserAssetsDataList_ctl00_GameCreatorHyperLink" href="/users?id=<?php echo intval($creator['id']); ?>"><?php echo $GLOBALS['site']->cleanOutput($creator['username']); ?></a></span></div>
             <?php if($item['bux']){ ?>
                <div class="AssetPrice">
              <span class="PriceInRobux">R$: <?php echo intval($item['bux']); ?></span>
            </div>            <?php } ?>
              <?php if($item['tix']){ ?>
                <div class="AssetPrice">
              <span class="PriceInTickets">Tx: <?php echo intval($item['tix']); ?></span>
            </div>            <?php } ?> 
            </div>
          </div></td>
            <?php if (($i + 1) % 5 === 0) { ?>
            </tr><tr>
        <?php } ?>
         <?php } ?>
      </tr>
       <?php } ?>
    </tbody></table>
        
      </div>
      <div style="clear:both;"></div>
    </div>
  
  </div>
      </div>
    
</div>
  </div>
  

        </div>
<?php
}else{ 
//USERS PAGE
$usersp = new users(10); //pages = 10
$keyword = $_GET['Keyword'] ?? '';
//users' data
$data = $usersp->getUsers($_GET['page'] ?? 1, $keyword);
?>
<div id="Body">
          
                              <div>
                  <div id="BrowseContainer" style="text-align:center">
                    <input id="SKeyword" type="text" value="" maxlength="100">&nbsp;<a href="javascript:window.location.href='?Keyword='+document.getElementById('SKeyword').value">Search</a>
                    <br><br>
                    <div>
                                            <table class="Grid" cellspacing="0" cellpadding="4" border="0" style="border-collapse:collapse;">
                        <tbody><tr class="GridHeader">
                          <th scope="col">Avatar</th><th scope="col"><a href="javascript:__doPostBack('ctl00$cphRoblox$gvUsersBrowsed','Sort$userName')">Name</a></th><th scope="col">Status</th><th scope="col"><a href="javascript:__doPostBack('ctl00$cphRoblox$gvUsersBrowsed','Sort$lastActivity')">Location / Last Seen</a></th>
                        </tr>
                        
                                                <?php if ($data['users']): //hi ?>
            <?php foreach ($data['users'] as $USER): //not finished yet ?>
              <tr class="GridItem">
                <td>
                  <a title="<?php echo $GLOBALS['site']->cleanOutput($USER->username); ?>" href="/users?id=<?php echo $USER->id; ?>" style="display:inline-block;height:48px;width:48px;cursor:pointer;">
                    <img style="height:48px;width:48px" src="<?php echo $GLOBALS['baseURL']; ?>/goodblox/images/render/avatar/<?php echo $USER->id; ?>-small.png" alt="<?php echo $GLOBALS['site']->cleanOutput($USER->username); ?>" onerror="this.onerror=null; this.src='<?php echo $GLOBALS['baseURL']; ?>/goodblox/images/render/avatar/default-small.png';">
                  </a>
                </td>
                <td>
                  <a href="/users?id=<?php echo $USER->id; ?>"><?php echo $GLOBALS['site']->cleanOutput($USER->username); ?></a><br>
                  <span><?php echo nl2br($GLOBALS['site']->cleanOutput($USER->blurb ?? '')); ?></span>
                </td>
                <td>
                  <span><?php echo $USER->lastseen + 300 <= time() ? 'Offline' : 'Online'; ?></span><br>
                </td>
                <td>
                  <span>Website</span>
                </td>
              </tr>
            <?php endforeach; ?>
          <?php else: ?>
          <?php endif; ?>
<tr class="GridPager">
  <td colspan="4">
    <table border="0">
      <tr>
        <?php
        $lolz = 10; //10 as supposed I think
        $page = (int)$data['current']; 
        $start = max(1, min($page - floor($lolz / 2), $data['totalpegs'] - $lolz + 1));
        $end = min($data['totalpegs'], $start + $lolz - 1);
        //whirpool was here
        if ($page > 1) echo '<td><a href="?page='.($page-1).($keyword? '&Keyword='.urlencode($keyword):'').'"></a></td>'; //should work
        //update -alex4521: yall put wrong $start at the first, that's why it gave errors
        for ($i = $start; $i <= $end; $i++):
            echo '<td>'.($i==$page? "<span><b>$i</b></span>" : '<a href="?page='.$i.($keyword? '&Keyword='.urlencode($keyword):'').'">'.$i.'</a>').'</td>';
        endfor;
        //no way this will fix the 1/1 error
        if ($page < $data['totalpegs']) echo '<td><a href="?page='.($page+1).($keyword? '&Keyword='.urlencode($keyword):'').'"></a></td>';
        ?>
      </tr>
    </table>
  </td>
</tr>                    </tbody></table>                    </div>
                  </div>
                </div>
                      </div>
<?php } ?>
<?php print($GLOBALS['site']->getFooter());  //no way ?>