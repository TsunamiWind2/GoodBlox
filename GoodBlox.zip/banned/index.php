<?php
require '../goodblox/core/config.php';
$GLOBALS['site'] = new site();
print($GLOBALS['site']->getDependencies(1, "GoodBlox | Disabled Account", "GoodBlox is a 2007 revival aiming to replicate ROBLOX as it was in 2007!", $GLOBALS['baseURL'].'resources/images/logo.png'));
print($GLOBALS['site']->getHeader(false)); //true - show nav, false - dont show nav
//banned stuff
$diff = $GLOBALS['banned']['unactivation_date'] - $GLOBALS['banned']['ban_date'];
$days = round($diff / 86400);
if($GLOBALS['banned']['type'] === 1) {
  //idk wtf this is 
  $h2 = 'Banned for '.$days.' days';
  $panel3 = true;
}elseif($GLOBALS['banned']['type'] === 5) {
  //smh hacking code
  $h2 = 'Banned for '.$days.' days';
  $panel3 = false;
}
?>

<div id="Body">
          
    
    <div style="margin: 150px auto 150px auto; width: 500px; border: black thin solid; padding: 22px;">
        <h2>
            <?php echo $h2; ?>
        </h2>
        <p>
            Our content monitors have determined that your behavior at GOODBLOX has been in violation of our Terms of Service. We will terminate your account if you do not abide by the rules.</p>
        <p>
            Reason:<span style="font-weight: bold">
                <?php echo $GLOBALS['site']->cleanOutput($GLOBALS['banned']['reason']); ?></span>
            <br>
            Source:<span style="font-weight: bold">
                Site</span>
            <br>
            Reported:<span style="font-weight: bold">
                <?php echo date("n/j/Y g:i:s A", $GLOBALS['banned']['ban_date']); ?></span>
        </p>
        <p>
            <span style="font-weight: bold">
                <?php echo $GLOBALS['site']->cleanOutput($GLOBALS['banned']['notes']); ?></span>
        </p>
        <p>
            Please abide by the <a href="http://wiki.roblox.com/index.php?title=Community_Guidelines">ROBLOX Community Guidelines</a> so that ROBLOX can be fun for users of all ages.
        </p>
        
        
        <?php if($panel3) { ?><div id="ctl00_cphRoblox_Panel3">
  
            <p>
                Your account has been disabled for 14 days. You may re-activate it after
                <span id="ctl00_cphRoblox_Label6"><?php echo date("n/j/Y g:i:s A", $GLOBALS['banned']['unactivation_date']); ?></span><br>
            </p>
        
</div><?php } ?>
        <div id="ctl00_cphRoblox_UpdatePanel1">
  
                
            
</div>
    </div>

        </div>
<?php print($GLOBALS['site']->getFooter()); ?>