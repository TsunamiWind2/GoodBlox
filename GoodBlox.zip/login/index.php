<?php
require '../goodblox/core/config.php';
$GLOBALS['site'] = new site();
print($GLOBALS['site']->getDependencies(1, "GoodBlox: We're Good", "GoodBlox is a 2007 revival aiming to replicate ROBLOX as it was in 2007!", $GLOBALS['baseURL'].'resources/'));
print($GLOBALS['site']->getHeader(true)); //true - show nav, false - dont show nav
if($GLOBALS['user']->isLoggedIn()) {
  header('Location: /'); //new
  die();
}
//some cool login
$err = '';  
if(isset($_POST['lb'])) {
    //login post
    $un = trim($_POST['un']);
    $pw = $_POST['pw'];
    $stmt = $pdo->prepare("SELECT * FROM users WHERE username = :un LIMIT 1");
    $stmt->execute(['un' => $un]);
    $usr = $stmt->fetch(PDO::FETCH_ASSOC);
    if($usr && password_verify($pw, $usr['password'])) {
        //uid, token, ip, country = null, user_agent, valid = 1
        $token = bin2hex(random_bytes(32));
        $userip = hash('sha256', $_SERVER['REMOTE_ADDR']);
        $GLOBALS['authentication']->createSESSION(intval($usr['id']), $token, $userip, $_SERVER['HTTP_USER_AGENT']);
        //success
        header("Location: /");
        die();
    } else {
        //real goodblox error
        $err = "Incorrect username or password. Please try again.";
    }
}
?>
<div id="Body">
  <div id="FrameLogin" style="margin: 50px auto 150px auto; width: 500px; border: black thin solid; padding: 22px; z-index: 8; background-color: white;">
    <div id="PaneNewUser">
      <h3>New User?</h3>
      <p>You need an account to play GoodBlox.</p>
      <p>If you aren't a GoodBlox member then <a href="/signup">register</a>. It's easy and we do <em>not</em> share your personal information with anybody.</p>
    </div>
    <div id="PaneLogin">
      <h3>Log In</h3>
      <div class="AspNet-Login">
        <form class="AspNet-Login" method="post">
          <?php if(isset($err)) { ?><div style="color:red;"><?php echo $err; ?></div><?php } ?>
          <div class="AspNet-Login-UserPanel">
            <label for="ctl00_cphRoblox_lRobloxLogin_UserName" class="TextboxLabel"><em>U</em>ser Name:</label>
            <input id="ctl00_cphRoblox_lRobloxLogin_UserName" name="un" accesskey="u" style="background-image: url(&quot;data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAASCAYAAABSO15qAAAAAXNSR0IArs4c6QAAAPhJREFUOBHlU70KgzAQPlMhEvoQTg6OPoOjT+JWOnRqkUKHgqWP4OQbOPokTk6OTkVULNSLVc62oJmbIdzd95NcuGjX2/3YVI/Ts+t0WLE2ut5xsQ0O+90F6UxFjAI8qNcEGONia08e6MNONYwCS7EQAizLmtGUDEzTBNd1fxsYhjEBnHPQNG3KKTYV34F8ec/zwHEciOMYyrIE3/ehKAqIoggo9inGXKmFXwbyBkmSQJqmUNe15IRhCG3byphitm1/eUzDM4qR0TTNjEixGdAnSi3keS5vSk2UDKqqgizLqB4YzvassiKhGtZ/jDMtLOnHz7TE+yf8BaDZXA509yeBAAAAAElFTkSuQmCC&quot;); background-repeat: no-repeat; background-attachment: scroll; background-size: 16px 18px; background-position: 98% 50%;" autocomplete="off" type="text">&nbsp;
          </div>
          <div class="AspNet-Login-PasswordPanel">
            <label for="ctl00_cphRoblox_lRobloxLogin_Password" class="TextboxLabel"><em>P</em>assword:</label>
            <input id="ctl00_cphRoblox_lRobloxLogin_Password" name="pw" value="" accesskey="p" style="background-image: url(&quot;data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAASCAYAAABSO15qAAAAAXNSR0IArs4c6QAAAPhJREFUOBHlU70KgzAQPlMhEvoQTg6OPoOjT+JWOnRqkUKHgqWP4OQbOPokTk6OTkVULNSLVc62oJmbIdzd95NcuGjX2/3YVI/Ts+t0WLE2ut5xsQ0O+90F6UxFjAI8qNcEGONia08e6MNONYwCS7EQAizLmtGUDEzTBNd1fxsYhjEBnHPQNG3KKTYV34F8ec/zwHEciOMYyrIE3/ehKAqIoggo9inGXKmFXwbyBkmSQJqmUNe15IRhCG3byphitm1/eUzDM4qR0TTNjEixGdAnSi3keS5vSk2UDKqqgizLqB4YzvassiKhGtZ/jDMtLOnHz7TE+yf8BaDZXA509yeBAAAAAElFTkSuQmCC&quot;); background-repeat: no-repeat; background-attachment: scroll; background-size: 16px 18px; background-position: 98% 50%;" autocomplete="off" type="password">&nbsp;
          </div>
          <div class="AspNet-Login-SubmitPanel">
            <input value="Log In" id="ctl00_cphRoblox_lRobloxLogin_LoginButton" name="lb" type="submit">
          </div>
        </form>
        <div class="AspNet-Login-PasswordRecoveryPanel">
          <a id="ctl00_cphRoblox_ImageFigure" disabled="disabled" title="Forgot your password?" onclick="return false" style="display:inline-block;">
            <img src="/resources/fgtpwspeech.png" id="img" alt="Forgot your password?" blankurl="http://t1.roblox.com:80/blank-115x130.gif" border="0" onclick="window.location.href='/oopsiforgot'" style="position:absolute;margin-left:200px;cursor:pointer;">
            <img src="/resources/loginfig.png" id="img" alt="Figure" blankurl="http://t1.roblox.com:80/blank-115x130.gif" border="0" style="margin-left: 80px;position:absolute;z-index:-1;margin-top:-50px;">
          </a>
        </div>
      </div>
    </div>
  </div>    
</div>
<?php print($GLOBALS['site']->getFooter()); ?>