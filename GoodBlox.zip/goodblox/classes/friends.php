<?php
//goodblox friends class real
class friends {
  private $uid; //user id
  public function __construct(?int $uid = null){
    //eee
    $this->uid = $uid;  
  }
  //getfriends by $FRIENDS = getFriends();
  public function getFriends():?array{
    $stmt = $GLOBALS['pdo']->prepare("SELECT * FROM friends WHERE uid = :uid OR fid = :fid ORDER BY time_added ASC LIMIT 6");
    $stmt->execute([
       //will fix this later
       'uid' => $this->uid,
       'fid' => $this->uid
    ]);
    $friends = $stmt->fetchAll(PDO::FETCH_ASSOC); //I forgot that I used fetch for everything
    return $friends ?: null;
  }
  //2025-09-20
  public function getFriendsV2(int $page = 1, int $perPage = 30): ?array {
    //using arrays no std class btw
    //if you can dynamic this, go ahead
    $offset = ($page - 1) * $perPage;
    $stmt = $GLOBALS['pdo']->prepare("
        SELECT * 
        FROM friends 
        WHERE uid = :uid OR fid = :fid 
        ORDER BY time_added ASC 
        LIMIT :limit OFFSET :offset
    ");
    //had to use goblox src to finish this :)
    //hi jack
    $stmt->bindValue(':uid', $this->uid, PDO::PARAM_INT);
    $stmt->bindValue(':fid', $this->uid, PDO::PARAM_INT);
    $stmt->bindValue(':limit', $perPage, PDO::PARAM_INT);
    $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
    //I almost forgot the offset stuff again :/
    $stmt->execute();
    $friends = $stmt->fetchAll(PDO::FETCH_ASSOC);
    return $friends ?: [];
  }
  //fetch total friends
  public function getFriendsTotal():int{
    $stmt = $GLOBALS['pdo']->prepare("SELECT COUNT(*) FROM friends WHERE uid = :uid OR fid = :fid");
    $stmt->execute([
       'uid' => $this->uid,
       'fid' => $this->uid
       //I will add 2 uids to construct later
    ]);
    return (int)$stmt->fetchColumn();
    //total it
   }
   //get friend $uid and smh dude
   function getFriend(int $fid, int $uid, int $myself):?object{
     $stmt = $GLOBALS['pdo']->prepare("SELECT * FROM users WHERE (id = :fid OR id = :uid) AND id != :myself");
     $stmt->execute([
       ':fid' => $fid,
       ':uid' => $uid,
       ':myself' => $myself //this sucks tho,
     ]);
     $cat = $stmt->fetch(PDO::FETCH_OBJ); //using obj for this too
     return $cat ?: null;
  }
  //friend requests here peak
  public function getFriendRequests(int $uid):?array{
    $stmt = $GLOBALS['pdo']->prepare("SELECT * FROM friend_requests WHERE sid = :sid ORDER BY time_sent DESC LIMIT 6");
    $stmt->execute(['sid' => $uid]);
    //official goodblox friend_requests stuff
    $friends_requests = $stmt->fetchAll(PDO::FETCH_ASSOC);
    return $friends_requests ?: null;
  }
  //fetch total friend request
  public function getFriendRequestsTotal(int $uid):int{
    $stmt = $GLOBALS['pdo']->prepare("SELECT COUNT(*) FROM friend_requests WHERE sid = :sid");
    $stmt->execute([            
       //only uid I think
       'sid' => $uid
    ]);
    //yes yes ! yes ahhhh
    return (int)$stmt->fetchColumn();
  }
  //fetchh
  public function usert(int $uid): ?array{
    //fetch user by his uid
    //yess
    $stmt = $GLOBALS['pdo']->prepare("SELECT * FROM users WHERE id = :id");
    $stmt->execute([':id' => $uid]); //:idB4@/1
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    return $user ?: null;
  }
}
?>