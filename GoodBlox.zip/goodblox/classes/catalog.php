<?php
//hi, jack marston --rdr2
class catalog {
  //types
  private $browse;
  private $category;
  private $type;
  private $currency;
  private $keyword;
  //true
  //types: 1 = hat, 2 = shirts
  function __construct($browse = 'Featured', $category = 'Hats', $currency = 'All', $keyword = ''){
    if($category === 'Hats'){
      $this->type = 1;
    }elseif($category === 'Shirts'){
      $this->type = 2;
    }else{
      $this->type = 0;
    }
    //$this everything btw
    $this->browse = $browse;
    $this->category = $category;
    $this->currency = $currency;
    $this->keyword = $keyword;
  }
  //todo: add browse, currency and other.
  public function getCatalog($page = 1, $perPage = 20){
    $offset = ($page - 1) * $perPage;
    $lol = '';
    if (!empty($this->keyword)) {
     $lol = " AND name LIKE :keyword";
    }
    $stmt = $GLOBALS['pdo']->prepare("
        SELECT SQL_CALC_FOUND_ROWS * 
        FROM catalog_items 
        WHERE type = :type ".$lol."
        ORDER BY time_created DESC 
        LIMIT :limit OFFSET :offset
    ");
    //GOD HAD TO RESEARCH WHAT IS CALC_FOUND STUFF
    $stmt->bindValue(':type', $this->type, PDO::PARAM_INT);
    $stmt->bindValue(':limit', $perPage, PDO::PARAM_INT);
    if (!empty($this->keyword)){
      $stmt->bindValue(':keyword', '%' . $this->keyword . '%', PDO::PARAM_STR);
    }
    $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
    $stmt->execute();
    $items = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $total = $GLOBALS['pdo']->query("SELECT FOUND_ROWS()")->fetchColumn();
    return [
        'items' => $items,
        'total' => $total
    ];
  }
}
?>