<?php
//asset delivery class
class asset {
  private $id; //assetid
  private $type; //1 = hat xml, 2 = shirt xml, 3 = texture, 4 = mesh, 5 = model xml
  public function __construct(?int $id = null){
    $this->id = $id;  
  }
  //assets
  public function getAsset(){
    //get asset info
    $stmt = $GLOBALS['pdo']->prepare("SELECT * FROM assets WHERE id = :id");
    $stmt->bindParam(":id", $this->id, PDO::PARAM_INT);
    $stmt->execute();
    $asset = $stmt->fetch(PDO::FETCH_ASSOC);
    return $asset;
  }
  //catalog
  public function getItem(){
    //catalog
    $stmt = $GLOBALS['pdo']->prepare("SELECT * FROM catalog_items WHERE asset_id = :aid");
    $stmt->bindParam(":aid", $this->id, PDO::PARAM_INT);
    //using asset_id now
    $stmt->execute();
    $item = $stmt->fetch(PDO::FETCH_ASSOC);
    return $item;
  }
  //games
  public function getGame(){
    //games idk about them rn
    $stmt = $GLOBALS['pdo']->prepare("SELECT * FROM games WHERE id = :id");
    $stmt->bindParam(":id", $this->id, PDO::PARAM_INT);
    $stmt->execute();
    $game = $stmt->fetch(PDO::FETCH_ASSOC);
    return $game;
  }
  //very useful thing
  public function checkMimeType($file){
    $file_info = new finfo(FILEINFO_MIME_TYPE);
    return $file_info->buffer(file_get_contents($file));
  }
  //redirect >:)
  public function redirect($locationurl, $roblox){
     //finally bro
     $file = parse_url($locationurl, PHP_URL_PATH);
     $location = $_SERVER['DOCUMENT_ROOT'] . $file;
     if($roblox){
        //yes roadblocks
        header("Location: https://assetdelivery.roblox.com/v1/asset/?id=".$this->id."&version=1");
        exit;
     } else {
        //goodblox assets real
        if(!file_exists($location)){
            http_response_code(404);
            die('Request asset was not found');
        }
        $type = $this->checkMimeType($location); 
        header("Content-Type: $type");
        header("Content-Length: " . filesize($location));
        readfile($location);
        exit;
    }
  }
}
?>