<?php
//ban class by whirpool
class banHandler {
   private $uid; //user id
   private $reason; //reason
   private $notes; //some notes frm mod
   private $ban_date; //date
   private $unactiatedBy; //banned by mod id
   private $activated; //did he slide away
   private $unactivation_date; //unban day/time
   //checking if the user is banne4#$6\
   public function banned(int $uid): ?array {
        $stmt = $GLOBALS['pdo']->prepare("SELECT * FROM bans WHERE uid = :uid");
        $stmt->execute([':uid' => $uid]);
        $ban = $stmt->fetch(PDO::FETCH_ASSOC);
        return $ban ?: null;
   }
}
?>