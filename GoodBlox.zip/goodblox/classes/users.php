<?php
//goodblox users class fan made
class users {
  private $perpage;
  public function __construct(int $perpage = 10) {
      $this->perpage = $perpage;
  }
  //get users function
  public function getUsers(int $page = 1, string $keyword = ''): array {
    //page 1 - &/12
    $page = max($page, 1);
    $offset = ($page - 1) * $this->perpage;
    $sets = [];
    //$lol = settings
    $lol = '';
    if($keyword !== '') {
      $sets[':keyword'] = "%$keyword%";
      $lol = "WHERE username LIKE :keyword";
      //lol
    }
    $stmt = $GLOBALS['pdo']->prepare("SELECT COUNT(*) FROM users ".$lol."");
    //;9
    $stmt->execute($sets);
    $totalbros = (int)$stmt->fetchColumn();
    $totalpegs = (int)ceil($totalbros / $this->perpage);
    $stmt = $GLOBALS['pdo']->prepare("SELECT * FROM users ".$lol." ORDER BY lastseen DESC LIMIT :offset, :perpage"); //order by lastseen
    foreach ($sets as $k => $v) {
        $stmt->bindValue($k, $v); //_@k/@v(-/12)
    }
    $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
    $stmt->bindValue(':perpage', $this->perpage, PDO::PARAM_INT);
    //chang9
    $stmt->execute();
    $users = $stmt->fetchAll(PDO::FETCH_OBJ); //fetch obj for array
    return [
        'users' => $users,
        'totalbros' => $totalbros,
        'totalpegs' => $totalpegs,
        'current' => $page //yes
    ];
  }
}
?>