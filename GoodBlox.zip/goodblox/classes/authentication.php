<?php
//auth class by alex
class authentication{
  //9645@$45_/a
  private static $uid;
  private static $token;
  private static $ipUsed;
  private static $country;
  private static $user_agent;
  private static $valid;
  private static $last_used;
  private static $when_created;
  private static $type; //0 = Web, 1 = Admin
  //auth __construct
  function __construct() {
    if(isset($_SESSION['uid'])) {
      $this::$uid = $_SESSION['uid'];
    }
  }
  function getSESSION() {
    return $_SESSION;
  }
  //gotta make it securer some time
  function createSESSION($uid, $token, $ipUsed, $user_agent, $country = 'unknown', $valid = 1) {
    if(empty($uid) || empty($token) || empty($ipUsed) || empty($user_agent)) {
      return false; // required fields missing
    }
    $this::$uid = $uid;
    $this::$token = $token;
    $this::$ipUsed = $ipUsed;
    $this::$country = $country;
    $this::$user_agent = $user_agent;
    $this::$valid = $valid;
    $this::$last_used = time();
    $this::$when_created = time();
    //_SESSIONS conf
    $_SESSION['uid'] = $this::$uid; //user id
    $_SESSION['token'] = $this::$token; //csrf 
    $_SESSION['ipUsed'] = $this::$ipUsed; //hashed
    $_SESSION['country'] = $this::$country; //should be null
    $_SESSION['user_agent'] = $this::$user_agent;
    $_SESSION['valid'] = $this::$valid; //valid = 1
    $_SESSION['when_created'] = $this::$when_created; //time(); utc one
    $_SESSION['hwid'] = null; //for future use
    $stmt = $GLOBALS['pdo']->prepare("INSERT INTO sessions (uid, token, ipUsed, country, user_agent, valid, last_used, when_created) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->execute([$this::$uid, $this::$token, $this::$ipUsed, $this::$country, $this::$user_agent, $this::$valid, $this::$last_used, $this::$when_created]);
    return true;
  }
  //$this::_destory::_SESSION(1278l) {
  function deleteSESSION($uid = 0) {
    if($uid != 0) { 
      session_unset();
      session_destroy();
      $stmt = $GLOBALS['pdo']->prepare("UPDATE sessions SET valid = 0 WHERE uid = ?"); //goodblox
      $stmt->execute([$uid]);
      return true;
    }
  }
}
?>