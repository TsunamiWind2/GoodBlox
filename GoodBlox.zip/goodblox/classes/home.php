<?php
//goodblox home class by alex
class home {
  private $uid; //user id
  private $games; //exception, dunno if I should do it
  private $visits; //exception
  private $messages;
  private $owned_assets;
  //owned assets @_$32/1sa
  public function __construct(?int $uid = null){
    $this->uid = $uid;  
  }
  //$user = $GLOBALS['home']->user($id);
  public function bro(int $uid): ?array{
    //fetch user by his uid
    $stmt = $GLOBALS['pdo']->prepare("SELECT * FROM users WHERE id = :id");
    $stmt->execute([':id' => $uid]); //:idB4@/1
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    return $user ?: null;
  }
  //inventory
  //$hats = $GLOBALS['home']->inv('1'); 
  //1 = hat, 2 = shirt, 3 = model, 4 = decal
  public function inv(int $uid, int $type):?array{
    $stmt = $GLOBALS['pdo']->prepare("SELECT * FROM owned_assets WHERE uid = :uid AND type = :type ORDER BY id DESC LIMIT 15");
    $stmt->execute([':uid' => $uid, ':type' => $type]);
    $owned_assets = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $this->owned_assets = $owned_assets ?: null;
    return $this->owned_assets;
  }
}
?>