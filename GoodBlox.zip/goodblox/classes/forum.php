<?php
//forum class by alex
class forum {
   private $cid;
   //shit hardd
   public function getForumGroup($cid = 0){
      //WE ARE BACK!!1
      $stmt = $GLOBALS['pdo']->prepare("SELECT * FROM forum_groups WHERE id = :id");
      $stmt->execute([':id' => $cid]);
      return $stmt->fetch(PDO::FETCH_ASSOC);
   }
   //broski
   public function getForumCats($cat_title = 0){
      $stmt = $GLOBALS['pdo']->prepare("SELECT * FROM forum_categories WHERE cat_title = :cat_title");
      $stmt->execute([':cat_title' => $cat_title]);
      return $stmt->fetchAll(PDO::FETCH_ASSOC);
   }
   //good
   public function getForumTopics($cat_id = 0, $limit = 20, $offset = 0, $keyword = ''){
      //keyword 2025 !11
      $stmt = $GLOBALS['pdo']->prepare("SELECT * FROM forum_topics WHERE cat_id = :id ORDER BY pinned DESC, id DESC LIMIT :limit OFFSET :offset");
      if ($keyword !== '') {
        //yess
        $stmt = $GLOBALS['pdo']->prepare(
            "SELECT * FROM forum_topics 
             WHERE cat_id = :id AND title LIKE :keyword 
             ORDER BY pinned DESC, id DESC 
             LIMIT :limit OFFSET :offset"
        );
        //pinned first dude
        $stmt->bindValue(':id', $cat_id, PDO::PARAM_INT);
        $stmt->bindValue(':keyword', '%'.$keyword.'%', PDO::PARAM_STR);
      } else {
        //cool
        $stmt = $GLOBALS['pdo']->prepare(
            "SELECT * FROM forum_topics 
             WHERE cat_id = :id 
             ORDER BY pinned DESC, id DESC 
             LIMIT :limit OFFSET :offset"
        );
        $stmt->bindValue(':id', $cat_id, PDO::PARAM_INT);
      }
      //limit 20 btw
      $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
      $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
      $stmt->execute();
      return $stmt->fetchAll(PDO::FETCH_ASSOC);
   }
   //HELP
   public function getForumCat($id = 0){
      //ahhh
      $stmt = $GLOBALS['pdo']->prepare("SELECT * FROM forum_categories WHERE id = :id");
      $stmt->execute([':id' => $id]);
      //broo
      return $stmt->fetch(PDO::FETCH_ASSOC);
   }
   //pls
   public function getForumTotalTopics($cat_id = 0, $keyword = '') {
      //credits for me tho
      if ($keyword !== '') {
         $stmt = $GLOBALS['pdo']->prepare(
            "SELECT COUNT(*) as total FROM forum_topics WHERE cat_id = :id AND title LIKE :keyword"
         );
         //I forgot to add keyword lmao
         $stmt->execute([
            ':id' => $cat_id,
            ':keyword' => '%'.$keyword.'%'
         ]);
      } else {
         //default
         $stmt = $GLOBALS['pdo']->prepare(
            "SELECT COUNT(*) as total FROM forum_topics WHERE cat_id = :id"
         );
         $stmt->execute([':id' => $cat_id]);
      }
      //goblox too
      $result = $stmt->fetch(PDO::FETCH_ASSOC);
      return $result['total'] ?? 0;
   }
   //maybe
   public function getForumTopicReplies($topic_id = 0){
      $stmt = $GLOBALS['pdo']->prepare("SELECT COUNT(*) AS total FROM forum_replies WHERE topic_id = :id");
      $stmt->execute([':id' => $topic_id]);
      $result = $stmt->fetch(PDO::FETCH_ASSOC);
      return $result['total'] ?? 0;
   }
   public function getForumTotalReplies($cat_id = 0){
      $stmt = $GLOBALS['pdo']->prepare("SELECT COUNT(*) AS total FROM forum_replies WHERE cat_id = :id");
      $stmt->execute([':id' => $cat_id]);
      $result = $stmt->fetch(PDO::FETCH_ASSOC);
      return $result['total'] ?? 0;
   }
   //get noob
   public function getForumLastPost($cat_id = 0){
      $stmt = $GLOBALS['pdo']->prepare("SELECT * FROM forum_replies WHERE cat_id = :id ORDER BY post_date DESC LIMIT 1");
      $stmt->execute([':id' => $cat_id]);
      return $stmt->fetch(PDO::FETCH_ASSOC);
   }
   //lastpost
   public function getForumTopicLastPost($topic_id = 0){
      $stmt = $GLOBALS['pdo']->prepare("SELECT * FROM forum_replies WHERE topic_id = :topic_id ORDER BY post_date DESC LIMIT 1");
      $stmt->execute([':topic_id' => $topic_id]);
      return $stmt->fetch(PDO::FETCH_ASSOC);
   }
   //fetch user
   public function getForumUser($user_id = 0){
      $stmt = $GLOBALS['pdo']->prepare("SELECT * FROM users WHERE id= :id");
      $stmt->execute([':id' => $user_id]);
      return $stmt->fetch(PDO::FETCH_ASSOC);
   }
}
?>