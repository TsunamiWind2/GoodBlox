<?php 
//$stuff = 'update|http://secretpassageway.goodblox.com/goodblox/api/scripts/render_server/tsnew.upd';

//type|queue_number|asset_id/user_id/hat_id_and_etc|hat_on_flag_if_user_has_hat_then_1
$queue = "0|3845|253|1";
exit($queue);
?>