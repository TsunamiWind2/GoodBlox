<?php
//not done yet, credits: vmultrafan
$thepass = "put your own password here";
$theusername = "your own username";
$username = $_GET['username'] ?? null;
$password = $_GET['password'] ?? null;
if(isset($_GET['queueid'])) {
  $queue = $_GET['queueid'];
  if($password == $thepass && $username == $theusername) {
    echo "pass is " . $password;
    echo "\nqueue is " . $queue;
  }
} 
?>