<?php
require $_SERVER["DOCUMENT_ROOT"].'/goodblox/core/config.php';
require $_SERVER["DOCUMENT_ROOT"].'/goodblox/classes/asset.php';
//ase5486t
//by moskau
$id = intval($_GET["id"]); 
$assetdelivery = new asset($id);
$asset = $assetdelivery->getAsset();
//added check for roblox delivery too
if($asset){
  //load them 
  $assetdelivery->redirect($asset['location'], false);
  echo $asset['location'];
}else{
  http_response_code(404);
  //bye bye :)
  die('Request asset was not found');
}
?>