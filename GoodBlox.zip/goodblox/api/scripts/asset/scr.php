<?php //todo: add types ?>
for _,v in pairs(game.GuiRoot:GetChildren()) do v:Remove() end
game.Lighting.TimeOfDay = '12'
if not game.Players:GetChildren()[1] then game.Players:CreateLocalPlayer(0) end
plr = game.Players.LocalPlayer
plr.CharacterAppearance = 'http://rhodu.k.vu/goodblox/api/scripts/asset/bodycol?uid=1'
plr:LoadCharacter()
