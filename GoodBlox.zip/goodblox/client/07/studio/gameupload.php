<!DOCTYPE html>
<html>
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
    <style>
      html {
        width:100%;
        height:100%;
      }
      body {
        min-width:100%;
        min-height:100%;
        background-color:blue;
        color:white;
      }
    </style>
    <script>
        function test()
        {
          try
          {
            var ret = window.external.execScript('print("hi")');
            //$('.PlaceResult').html(ret);
          }
          catch (ex)
          {
            alert("It seems that you are missing libraries from your computer that are required for in-client tools to work. Please check the GoodBlox discord for more information, or #help if you need help. Please screenshot the following alert when you make your post.");
            var ret = window.external.execScript('print("hi")');
          }
        }
        function exit() {
          try
          {
            var ret = window.external.execScript('print("hi")');
            //$('.PlaceResult').html(ret);
          }
          catch (ex)
          {
            window.close();
          }
        }
        test()
        exit()
    </script>
  </head>
  <body>
    <script>
      exit()
    </script>
    If you are seeing this, this means that libraries are missing from your computer that are required for in-client tools to work. Please check the GoodBlox discord for more information, or #help if you need help.
  </body>
</html>