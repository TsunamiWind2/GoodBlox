<?php
//GET OU-
if (strpos($_SERVER['SCRIPT_NAME'], "includes.php")){
  header("Location: /err");
  die();
}
//sessions declaration
session_name("GOODBLOX_Cookie");
session_start();
date_default_timezone_set('UTC');  
//modified 21/03/2021 by alex
require __DIR__.'/../../goodblox/core/db.php';
require __DIR__.'/../../goodblox/core/user.php';
require __DIR__.'/../../goodblox/classes/authentication.php';
require __DIR__.'/../../goodblox/classes/banHandler.php';
//db conf  
try {
    $GLOBALS['pdo'] = new PDO("mysql:host=$DB_HOST;dbname=$DB_NAME;charset=utf8mb4",$DB_USER,$DB_PASS,[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_OBJ,PDO::ATTR_EMULATE_PREPARES=>false]);
} catch (PDOException $e) {
    throw new PDOException($e->getMessage(), (int)$e->getCode());
}
//goodblox's site settings remain still
$GLOBALS['site_settings'] = $GLOBALS['pdo']->query("SELECT * FROM site_settings LIMIT 1")->fetch(PDO::FETCH_OBJ);
$GLOBALS['baseURL'] = 'http://rhodu.k.vu/'; //this might be temp
$GLOBALS['resourcesURL'] = '/resources/';
$GLOBALS['scriptsURL'] = '/js/';
$GLOBALS['user'] = new user(); //logged in sucks
$GLOBALS['self'] = $GLOBALS['user']->getUser(); //session user
$GLOBALS['authentication'] = new authentication(); //fixes
//banHandler for exceptions cases
$GLOBALS['banHandler'] = new banHandler();
//maintenance new 2025
if($GLOBALS['site_settings']->maintenance && !$GLOBALS['user']->isAdmin()){
   if($_SERVER['PHP_SELF'] !== '/maintenance/index.php') {
      header('Location: /maintenance');
      die();
      //get out
   }
}
//logged in settings
if($GLOBALS['user']->isLoggedIn()){
  //last seen function online/offline
  $time = time();
  $stmt = $pdo->prepare("UPDATE users SET lastseen = :time WHERE id = :id");
  $stmt->bindParam(':time', $time, PDO::PARAM_STR);
  $stmt->bindParam(':id', $GLOBALS['self']->id, PDO::PARAM_INT);
  $stmt->execute();
  //protected ban safety
  $GLOBALS['banned'] = $GLOBALS['banHandler']->banned(intval($GLOBALS['self']->id)); //trust
  if($GLOBALS['banned']) {
    //using php_self now
    if($_SERVER['PHP_SELF'] !== '/banned/index.php') {
      header('Location: /banned');
      die();
      //get out
    }
  }else {
    //uh well
    if($_SERVER['PHP_SELF'] === '/banned/index.php') {
      //hi! come back 
      header('Location: /');
      die();
    }
  }
}
//error handler 
function exception($seenbyuser, $type, $page, $postvars, $getvars, $sessionid, $user_agent, $ip, $msg, $timestamp, $string, $string2){
    //updated 06/06/2024 by alex
    $stmt = $GLOBALS['pdo']->prepare("INSERT INTO exceptions (seenbyuser, type, page, postvars, getvars, sessionid, user_agent, ip, msg, timestamp, string, string2) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->execute([$seenbyuser, $type, $page, $postvars, $getvars, $sessionid, $user_agent, $ip, $msg, $timestamp, $string, $string2]);    
}        
set_error_handler(function($errno, $errstr, $errfile, $errline){
    //error system stuff
    $page = $_SERVER['REQUEST_URI'];
    $postvars = http_build_query($_POST);
    $seenbyuser = $GLOBALS['user']->isLoggedIn() ? 1 : 0;
    //seenbyuser is session stuff btw
    $type = $errno; //might change this too
    $getvars =  http_build_query($_GET);
    $sessionid  = isset($GLOBALS['self']->id) ? intval($GLOBALS['self']->id) : 0;
    $user_agent = $_SERVER['HTTP_USER_AGENT'];
    $ip = hash('sha256', $_SERVER['REMOTE_ADDR']);
    $timestamp = time();
    //limit string length to 255 to avoid issues -alex
    $string = hash('sha256', $errfile);
    $string2 = hash('sha256', $errline);
    exception($seenbyuser, $type, $page, $postvars, $getvars, $sessionid, $user_agent, $ip, $errstr, $timestamp, $string, $string2);
    //error page
    die('<script type="text/javascript">window.location.href = "/err/";</script>');
});
?>