<?php
//GET OU-
if (strpos($_SERVER['SCRIPT_NAME'], "db.php")) {
  header("Location: /err");
  die();
}
//db config
$DB_USER = 'm30647_rhodum2';
$DB_PASS = '9t$gcfYNRh1yg.6ZnV4QfK0wM4?oA/';
$DB_NAME = 'm30647_rhodum2db';
$DB_HOST = 'mysql.ct8.pl';
?>