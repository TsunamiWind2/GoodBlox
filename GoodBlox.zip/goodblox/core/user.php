<?php
//user class by alex
//some spooky goodbloks stuf
class user {
  private static $uid;
  private static $type;
  //user checking __construct
  function __construct() {
    if(isset($_SESSION['uid'])) {
       $this::$uid = $_SESSION['uid']; //uid for now
       //dont change to id
    }
  }
  //log in
  function isLoggedIn() {
     if(isset($this::$uid)) {
        return true;
        //bool
     } else {
        return false;
     }
   }
    //admin check
   function isAdmin() {
     if($this->isLoggedIn()) {
         $this::$type = $GLOBALS['pdo']->query("SELECT `rank` FROM users WHERE id = ".$this::$uid)->fetchColumn();
         if($this::$type == 3) { //0 = member, 2 = mod, 3 = admin
            return true;    
         } else {
            return false;
         }
     } else {
         return false;
     }
   }
    //user fetch stuff
   function getUser() {
     if($this->isLoggedIn()) {
        return $GLOBALS['pdo']->query("SELECT * FROM users WHERE id = ".$this::$uid)->fetch();
        //return user query
     } else {
        return false;
     }
   }
}