<?php
require 'includes.php';
//error_reporting(E_ALL);
class site {
  public static $baseURL;
  public static $resourcesURL;
  public static $scriptsURL;
  public static $maintenance;
  public static $announcement;
  //check maintenance with __construct
  function __construct() {
     $this::$baseURL = $GLOBALS['baseURL'];
     $this::$resourcesURL = $GLOBALS['resourcesURL'];
     $this::$scriptsURL = $GLOBALS['scriptsURL'];
     $this::$maintenance = $GLOBALS['site_settings']->maintenance;
     $this::$announcement = $GLOBALS['pdo']->query("SELECT * FROM announcements");
     if(!( empty( $_SERVER['HTTP_X_FORWARDED_PHOTO'] ) || $_SERVER['HTTP_X_FORWARDED_PHOTO'] !== 'http' ) ) {
       header("Location: ".$this::$baseURL.$_SERVER['REQUEST_URI']);
       die();
     }
  }
  function getDependencies($ex = 1, $title = null, $description = null, $image = null) {
     $bds = '';
     if($_SERVER['PHP_SELF'] === '/badges/index.php'){
       $bds = '
<script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
<script>
  $(document).ready(function() {
    $("#Community").click(function() {
      $(".Community").toggle("slow");
    });

    $("#Builder").click(function() {
      $(".Builder").toggle("slow");
    });

    $("#Friendship").click(function() {
      $(".Friendship").toggle("slow");
    });

    $("#Combat").click(function() {
      $(".Combat").toggle("slow");
    });
  });
</script>';
     }
     $depend = '
<!DOCTYPE html>
<title>'.$title.'</title>
<link rel="stylesheet" type="text/css" href="/resources/AllCSS.css">
<link rel="Shortcut Icon" type="image/ico" href="/resources/goodblox128.ico">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta name="author" content="GoodBlox"><meta name="description" content="GoodBlox is Good.">
<meta name="keywords" content="game, video game, building game, contstruction game, online game, LEGO game, LEGO, MMO, MMORPG, virtual world, avatar chat">
<meta name="robots" content="all">'.$bds.'
<meta property="og:title" content="GoodBlox">
<meta property="og:description" content="GoodBlox is a 2007 revival aiming to replicate ROBLOX as it was in 2007!">
<meta property="og:url" content="">
<meta property="og:type" content="website">
<meta property="og:image" content="">
<meta name="theme-color" content="#FF0000">
';
     return $depend;
  }
  function getHeader($a) {
    $header = '
    <div id="Container">
  <div id="Header">
    <div id="Banner">
                            <div id="Options">
                    '.$this->getElement('auth', $a).'
                    <div id="Settings">
                    </div>
                </div>
            
      <div id="Logo">
        <a title="GoodBlox" href="/" style="display:inline-block;cursor:pointer;">
          <img src="/resources/logo.png" alt="GoodBlox" border="0">
        </a>
      </div>

                            '.$this->getElement('signup', $a).'
                </div>
                '.$this->getNavigation($a).'
                   </div> <div id="something">';
    $stmt = $GLOBALS['pdo']->query("SELECT * FROM announcements ORDER BY id DESC LIMIT 3");
    $this::$announcement = $stmt->fetch(PDO::FETCH_ASSOC);
    if($this::$maintenance) {
      $header .= '<div class="SystemAlert">
            <div class="SystemAlertText" style="background-color: red;">
              <div class="Exclamation">
              </div>
              <div>Maintenance is enabled</div>
            </div>
          </div>';
    }
    if(!($GLOBALS['site_settings']->thumb) && $GLOBALS['user']->isAdmin()) {
      $header .= '<div class="SystemAlert">
            <div class="SystemAlertText" style="background-color: orange;">
              <div class="Exclamation">
              </div>
              <div>Thumbnail server is disabled</div>
            </div>
          </div>';
    }
    if(!($GLOBALS['site_settings']->thumbUpdating) && $GLOBALS['user']->isAdmin()) {
      $header .= '<div class="SystemAlert">
            <div class="SystemAlertText" style="background-color: orange;">
              <div class="Exclamation">
              </div>
              <div>Thumbnail server is updating</div>
            </div>
          </div>';
    }
    //announcements system made by xpkneon, feel free to change if you need to
    if($a && $this::$announcement['announcement'] != "") {
      $announcementbg = $this::$announcement['color'];
      $announcementtxt = $this::$announcement['announcement'];
      $header .= '<div class="SystemAlert">
            <div class="SystemAlertText" style="background-color: '.$announcementbg.';">
              <div class="Exclamation">
              </div>
              <div>'.$this->cleanOutput($announcementtxt).'</div>
            </div>
          </div>';
    }
    $header .= "</div>";
    return $header;
  }
  function getNavigation($a) {
    if(!$a) {
      return '';
    }
    $nav = '<div class="Navigation">
      <span>
        <a class="MenuItem" href="/my/home">My GoodBlox</a>
      </span>
      <span class="Separator">&nbsp;|&nbsp;
      </span>
      <span>
        <a class="MenuItem" href="/games">Games</a>
      </span>
      <span class="Separator">
        &nbsp;|&nbsp;
      </span>
      <span>
        <a class="MenuItem" href="/catalog">Catalog</a>
      </span>
      <span class="Separator">
        &nbsp;|&nbsp;
      </span>
      <span>
        <a class="MenuItem" href="/buildersclub">Builders Club</a>
      </span>
      <span class="Separator">
      &nbsp;|&nbsp;
      </span>
      <span>
        <a class="MenuItem" href="/users">Browse</a>
      </span>
      <span class="Separator">
        &nbsp;|&nbsp;
      </span>
      <span>
        <a class="MenuItem" href="/forum">Forum</a>
      </span>
      <span class="Separator">
      &nbsp;|&nbsp;
      </span>
      <span>
        <a class="MenuItem" href="">News</a>
      &nbsp;
        <a id="NewsFeed" href=""><img src="/resources/feed-icon-14x14.png" style="border-width:0px;margin-left:-10px;"></a>
      </span>
    </div>';
    return $nav;
  }
  //please don't change anything here
  function getElement($b = null, $a = null) { //hard smh
    $element = '';
    if($b == 'signup' && $a) {
      if($GLOBALS['user']->isLoggedIn()) {
          if($GLOBALS['self']->robux > 0) {
            $rx = '<div id="ctl00_rbxAlerts_RobuxAlertPanel">
       
          <div id="RobuxAlert">
              <a id="ctl00_rbxAlerts_RobuxAlertIconHyperLink" class="RobuxAlertIcon" href="#"><img src="/resources/Robux.png" style="border-width:0px;"></a>&nbsp;
            <a id="ctl00_rbxAlerts_RobuxAlertCaptionHyperLink" class="RobuxAlertCaption" href="#">'.intval($GLOBALS['self']->robux).' ROBUX</a>
          </div>
        
  </div>';
          } else {
            //shit
            $rx = '';
          }
          if($GLOBALS['self']->tickets > 0) {
            $tx = '       <div id="ctl00_rbxAlerts_TicketsAlertPanel">
    
          <div id="TicketsAlert">
              <a id="ctl00_rbxAlerts_TicketsAlertIconHyperLink" class="TicketsAlertIcon" href="#"><img src="/resources/Tickets.png" style="border-width:0px;"></a>&nbsp;
            <a id="ctl00_rbxAlerts_TicketsAlertCaptionHyperLink" class="TicketsAlertCaption" href="#">'.intval($GLOBALS['self']->tickets).' Tickets</a>
          </div>
        
  </div>';
          } else {
            $tx = '';
          }
          //let's go dababy gahook :3
          if($GLOBALS['self']->tickets > 0 || $GLOBALS['self']->robux > 0) {
            $element = '<div id="Alerts"><table style="width:100%;height:100%"><tbody><tr><td valign="middle">

<div id="ctl00_rbxAlerts_AlertSpacePanel">
  
      <div id="AlertSpace">
       '.$rx.'
       '.$tx.'
      </div>

</div></td></tr></tbody></table></div>';
          } else {
            $element = '';
          }

      } else { 
          $element = '<div style="float: right; height: 72px; width: 287px;">
                    <table style="width:100%;height:100%">
                        <tbody>
                            <tr>
                                <td valign="middle">
                                    <a class="SignUpAndPlay" href="/signup">
                                        <img src="/resources/SignupBanner.png" alt="Sign-up and Play!" border="0">
                                    </a>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>';
      }
    } elseif($b == 'auth' && $a) {
      if($GLOBALS['user']->isLoggedIn()) {
             $element = '<div id="Authentication">
                <span><span id="ctl00_lnLoginName">Logged in as '.$this::cleanOutput($GLOBALS['self']->username).' | </span><a id="ctl00_lsLoginStatus" href="/logout">Logout</a></span>
              </div>';
      } else {
      $element = '<div id="Authentication">
                        <span><a href="/login">Login</a></span>
                    </div>';
      }
    }
    return $element;
  }
  function getFooter() {
    $foot = "<div id='Footer'>
    <hr>
    <p class='Legalese'>
    GoodBlox, 'A Good Online Toy', characters, logos, names, and all related indicia are trademarks of <a id='ctl00_rbxFooter_hlRobloxCorporation' href='/info/About.aspx'>ROBLOX Corporation</a>,
    ©2007. Patents pending.<br>
    GoodBlox is not affliated with Lego, ROBLOX, MegaBloks, Bionicle, Pokemon, Nintendo, Lincoln Logs, Yu Gi Oh, K'nex, Tinkertoys, Erector Set, or the Pirates of the Caribbean. ARrrr!<br>
  </p></div>";
    return $foot;
  }
  function cleanOutput($text ) {
    if(!empty($text)) {
      return rtrim(htmlspecialchars($text));
    }else {
      return '';
    }
  }
}
?>