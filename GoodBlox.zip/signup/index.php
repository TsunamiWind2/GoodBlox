<?php
require '../goodblox/core/config.php';
$GLOBALS['site'] = new site();
print($GLOBALS['site']->getDependencies(1, "GoodBlox: We're Good", "GoodBlox is a 2007 revival aiming to replicate ROBLOX as it was in 2007!", $GLOBALS['baseURL'].'resources/'));
print($GLOBALS['site']->getHeader(false)); //true - show nav, false - dont show nav
if($GLOBALS['user']->isLoggedIn()) {
  header('Location: /'); //new
  die();
}
//errors, might do advanced error handler later
$err_un_1 = '';
$err_un_2 = '';  
$err_pw_1 = '';
$err_pw_2 = '';
$err_cpw = '';
$err_e = '';
$err_beta = '';
//now with pdo db
if (isset($_POST['rb'])) {
    //register stuff
    $un = trim($_POST['un']); //username
    $pw = $_POST['pw']; //password
    $cpw = $_POST['cpw']; //conf password
    $e = $_POST['e']; //email
    $betakey = $_POST['betakey']; //beta key
    if (!preg_match('/^[A-Za-z0-9]{3,20}$/', $un)) {
        $err_un_1 = "This username cannot be used";
    }
    if(!filter_var($e, FILTER_VALIDATE_EMAIL)) {
        $err_e = "This email is not valid.";  
    }  
    if(strlen($pw) < 4 || strlen($pw) > 20 || preg_match('/\s/', $pw)) {
        $err_pw_1 = "This password cannot be used"; 
        $err_pw_2 = "This password should use 4-10 characters, no spaces";   
    }
    if($pw != $cpw) {
        $err_cpw = "Passwords do not match";   
    }
    if(!empty($un)) {
        $check = $GLOBALS['pdo']->prepare("SELECT * FROM users WHERE username = :username LIMIT 1"); 
        $check->execute(['username'=>$un]); 
        $check_un = $check->fetch(PDO::FETCH_OBJ); //object now
        if($check_un) {
          //basic errors
          $err_un_1 = "This username is in use by somebody else.";
          $err_un_2 = "This username is already taken!Try ".str_replace(' ', '', $un)."".rand(10,196)."";
        } else {
          $check_2 = $GLOBALS['pdo']->prepare("SELECT * FROM beta_keys WHERE token = :token AND uses = 0 LIMIT 1");
          $check_2->execute(['token'=>$betakey]);
          $check_beta = $check_2->fetch(PDO::FETCH_OBJ);
          if($check_beta){
            $hpw = password_hash($pw, PASSWORD_DEFAULT);
            $csrf = md5(uniqid(rand(), true)); //yeah token bru
            $jd = time();
            $userip = hash('sha256', $_SERVER['REMOTE_ADDR']);
            //success
            $upd = $GLOBALS['pdo']->prepare("UPDATE beta_keys SET uses = 1 WHERE token = :token LIMIT 1");
            $upd->execute(['token' => $betakey]);
            $stmt = $GLOBALS['pdo']->prepare("INSERT INTO users (username, password, email, emailVerified, blurb, tickets, robux, daily_tix_timestamp, betakeyUsed, joindate, lastseen, csrf_token, regip, `rank`, filter) VALUES (:username, :password, :email, 0, NULL, 0, 0, 0, 0, :joindate, 0, :csrf_token, :regip, 0, 0)");
            $stmt->execute(['username' => $un,'password' => $hpw,'email' => $e,'joindate' => $jd, 'csrf_token' => $csrf, 'regip' => $userip]);
            //continue with sessions now
            $userid = $GLOBALS['pdo']->lastInsertId();
            $GLOBALS['authentication']->createSESSION(intval($userid), bin2hex(random_bytes(32)), $userip, $_SERVER['HTTP_USER_AGENT'], 'unknown', 1);
            header("Location: /my/home");
            die();
          }else{
            $err_beta = 'This beta key is invalid.';
          }
        }
    }
}
?>
<div id="Body">
    <div id="Registration">
      <form method="post">
        <h2>Sign Up and Play</h2>
        <h3>Create Account</h3>
                        <div id="EnterUsername">
          <fieldset title="Choose a name for your GoodBlox character">
            <legend>Choose a name for your GoodBlox character</legend>
            <div class="Suggestion">
              Use 3-20 alphanumeric characters: A-Z, a-z, 0-9, no spaces
            </div>
            <div class="Validators">
                            <div style="color: red;"><?php echo $err_un_1; ?></div>
              <div style="color: red;"><?php echo $err_un_2; ?></div>
              <div></div>
              <div></div>
              <div></div>
            </div>
            <div class="UsernameRow">
              <label class="Label">Character Name:</label>&nbsp;<input maxlength="20" name="un" tabindex="1" class="TextBox" style="background-image: url(&quot;data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAASCAYAAABSO15qAAAAAXNSR0IArs4c6QAAAPhJREFUOBHlU70KgzAQPlMhEvoQTg6OPoOjT+JWOnRqkUKHgqWP4OQbOPokTk6OTkVULNSLVc62oJmbIdzd95NcuGjX2/3YVI/Ts+t0WLE2ut5xsQ0O+90F6UxFjAI8qNcEGONia08e6MNONYwCS7EQAizLmtGUDEzTBNd1fxsYhjEBnHPQNG3KKTYV34F8ec/zwHEciOMYyrIE3/ehKAqIoggo9inGXKmFXwbyBkmSQJqmUNe15IRhCG3byphitm1/eUzDM4qR0TTNjEixGdAnSi3keS5vSk2UDKqqgizLqB4YzvassiKhGtZ/jDMtLOnHz7TE+yf8BaDZXA509yeBAAAAAElFTkSuQmCC&quot;); background-repeat: no-repeat; background-attachment: scroll; background-size: 16px 18px; background-position: 98% 50%;" autocomplete="off" type="text">
            </div>
          </fieldset>
        </div>
        <div id="EnterPassword">
          <fieldset title="Choose your GoodBlox password">
            <legend>Choose your GoodBlox password</legend>
            <div class="Suggestion">
              Passwords must be atleast 8 characters
            </div>
            <div class="Validators">
                            <div style="color: red;"><?php echo $err_pw_1; ?></div>
              <div style="color: red;"><?php echo $err_pw_2; ?></div>
              <div></div>
              <div></div>
            </div>
            <div class="PasswordRow">
              <label class="Label">Password:</label>&nbsp;<input name="pw" tabindex="2" class="TextBox" style="background-image: url(&quot;data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAASCAYAAABSO15qAAAAAXNSR0IArs4c6QAAAPhJREFUOBHlU70KgzAQPlMhEvoQTg6OPoOjT+JWOnRqkUKHgqWP4OQbOPokTk6OTkVULNSLVc62oJmbIdzd95NcuGjX2/3YVI/Ts+t0WLE2ut5xsQ0O+90F6UxFjAI8qNcEGONia08e6MNONYwCS7EQAizLmtGUDEzTBNd1fxsYhjEBnHPQNG3KKTYV34F8ec/zwHEciOMYyrIE3/ehKAqIoggo9inGXKmFXwbyBkmSQJqmUNe15IRhCG3byphitm1/eUzDM4qR0TTNjEixGdAnSi3keS5vSk2UDKqqgizLqB4YzvassiKhGtZ/jDMtLOnHz7TE+yf8BaDZXA509yeBAAAAAElFTkSuQmCC&quot;); background-repeat: no-repeat; background-attachment: scroll; background-size: 16px 18px; background-position: 98% 50%;" autocomplete="off" type="password">
            </div>
            <div class="ConfirmPasswordRow">
              <label class="Label">Confirm Password:</label>&nbsp;<input name="cpw" tabindex="3" class="TextBox" style="background-image: url(&quot;data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAACIUlEQVQ4EX2TOYhTURSG87IMihDsjGghBhFBmHFDHLWwSqcikk4RRKJgk0KL7C8bMpWpZtIqNkEUl1ZCgs0wOo0SxiLMDApWlgOPrH7/5b2QkYwX7jvn/uc//zl3edZ4PPbNGvF4fC4ajR5VrNvt/mo0Gr1ZPOtfgWw2e9Lv9+chX7cs64CS4Oxg3o9GI7tUKv0Q5o1dAiTfCgQCLwnOkfQOu+oSLyJ2A783HA7vIPLGxX0TgVwud4HKn0nc7Pf7N6vV6oZHkkX8FPG3uMfgXC0Wi2vCg/poUKGGcagQI3k7k8mcp5slcGswGDwpl8tfwGJg3xB6Dvey8vz6oH4C3iXcFYjbwiDeo1KafafkC3NjK7iL5ESFGQEUF7Sg+ifZdDp9GnMF/KGmfBdT2HCwZ7TwtrBPC7rQaav6Iv48rqZwg+F+p8hOMBj0IbxfMdMBrW5pAVGV/ztINByENkU0t5BIJEKRSOQ3Aj+Z57iFs1R5NK3EQS6HQqF1zmQdzpFWq3W42WwOTAf1er1PF2USFlC+qxMvFAr3HcexWX+QX6lUvsKpkTyPSEXJkw6MQ4S38Ljdbi8rmM/nY+CvgNcQqdH6U/xrYK9t244jZv6ByUOSiDdIfgBZ12U6dHEHu9TpdIr8F0OP692CtzaW/a6y3y0Wx5kbFHvGuXzkgf0xhKnPzA4UTyaTB8Ph8AvcHi3fnsrZ7Wore02YViqVOrRXXPhfqP8j6MYlawoAAAAASUVORK5CYII=&quot;); background-repeat: no-repeat; background-attachment: scroll; background-size: 16px 18px; background-position: 98% 50%;" type="password">
            </div>
          </fieldset>
        </div>
        <div id="EnterEmail">
          <fieldset title="Provide your email address">
          <legend>Provide your email address</legend>
          <div class="Suggestion">
            This will allow you to recover a lost password
          </div>
          <div class="Validators">
                        <div style="color: red;"><?php echo $err_e; ?></div>
            <div></div>
            <div></div>
          </div>
          <div class="EmailRow">
            <label class="Label">Your Email:</label>&nbsp;<input name="e" tabindex="4" class="TextBox" type="text">
          </div>
          </fieldset>
        </div>
        <div id="EnterEmail">
          <fieldset title="Provide your email address">
          <legend>Enter your beta key</legend>
          <div class="Suggestion">
            To register on GoodBlox Beta
          </div>
          <div class="Validators">
            <div style="color: red;"><?php echo $err_beta; ?></div>
            <div></div>
            <div></div>
          </div>
          <div class="EmailRow">
            <label class="Label">Your Beta Key:</label>&nbsp;<input name="betakey" tabindex="4" class="TextBox" type="text">
          </div>
          </fieldset>
        </div>
        <div class="Confirm">
          <input name="rb" value="Register" tabindex="5" class="BigButton" type="submit">
        </div>

      </form>
    </div>
    <div id="Sidebars">
      <div id="AlreadyRegistered">
        <h3>Already Registered?</h3>
        <p>If you just need to login, go to the <a href="/login">Login</a> page.</p>
        <p>If you have already registered but you still need to download the game installer, go directly to <a href="/download">download</a>.</p>
      </div>
      <div id="TermsAndConditions">
        <h3>Terms &amp; Conditions</h3>
        <p>Registration does not provide any guarantees of service.</p>
        <p>GoodBlox will not share your email address with 3rd parties.</p>
      </div>
    </div>
    <div style="clear: both"></div>

    </div>
<?php print($GLOBALS['site']->getFooter()); ?>