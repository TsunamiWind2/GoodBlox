<?php
require '../goodblox/core/config.php';
//some epic logout made in 5 secs
if($GLOBALS['user']->isLoggedIn()) {
  $_SESSION = [];
  //sessions
  $stmt = $GLOBALS['pdo']->prepare("DELETE FROM sessions WHERE uid = :uid");
  $stmt->execute([':uid' => $GLOBALS['self']->id]);
  //real
  session_unset();
  session_destroy();
}
//yes
header("Location: /");
die();
?>